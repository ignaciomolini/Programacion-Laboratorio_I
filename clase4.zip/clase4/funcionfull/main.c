#include <stdio.h>
#include <stdlib.h>

int getIntRange(int* nota, char* mensaje, char* mensajeError , int min, int max, int intentos);

int main()
{
    int nota;
    int todoOk;

    todoOk = getIntRange(&nota, "Ingrese nota: ", "\nError. Reingrese nota: ", 0, 10, 3);

    if(todoOk == 0)
    {
        printf("\nNo se pudo conseguir la nota\n");

    }else
    {
        printf("\nLa nota ingresada es %d\n", nota);
    }

    return 0;
}

int getIntRange(int* nota, char* mensaje, char* mensajeError , int min, int max, int intentos)
{
    int todoOk = 1;
    int auxiliar;

    printf("%s", mensaje);
    scanf("%d", &auxiliar);

    while(auxiliar<min || auxiliar>max)
    {
        intentos--;
        if(intentos == 0)
        {
            todoOk = 0;
            break;
        }

        printf("%s", mensajeError);
        scanf("%d", &auxiliar);
    }

    if(intentos != 0)
    {
        *nota = auxiliar;
    }

    return todoOk;
}



