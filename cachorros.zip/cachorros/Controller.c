#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "LinkedList.h"
#include "Controller.h"
#include "Cachorro.h"
#include "parser.h"


/** \brief Carga los datos de los dominios desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListCachorro LinkedList*
 * \return int Retorna la cantidad de dominios cargados
 *
 */
int controller_loadFromText(char* path , LinkedList* pArrayListCachorro)
{
    int contador = 0;
    FILE* file = NULL;

    if(pArrayListCachorro != NULL && path != NULL)
    {
        file = fopen(path, "r");

        if(file != NULL)
        {
            contador = parser_CachorroFromText(file, pArrayListCachorro);
        }
    }

    fclose(file);

    return contador;
}


/** \brief Listar cachorro
 *
 * \param path char*
 * \param pArrayListCachorro LinkedList*
 * \return int Retorna la cantidad de dominios en la lista
 *
 */
int controller_ListCachorro(LinkedList* pArrayListCachorro)
{
    int contador = 0;

    if(pArrayListCachorro != NULL)
    {
        if(ll_isEmpty(pArrayListCachorro))
        {
            printf("\nNo hay dominios por mostrar.\n\n");
            return contador;
        }

        contador = mostrarCachorros(pArrayListCachorro);

    }
    return contador;
}



/** \brief Guarda los datos de los dominios en el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListCachorro LinkedList*
 * \return int Retorna 1 si se guardaron los datos
 *
 */
int controller_saveAsText(char* path , LinkedList* pArrayListCachorro)
{
    int todoOk = 0;
    int i;
    int largoArray = 0;
    FILE* file = NULL;
    eCachorro* auxCachorro = NULL;

    if(pArrayListCachorro != NULL && path != NULL)
    {
        largoArray = ll_len(pArrayListCachorro);

        file = fopen(path, "w");
        if(file == NULL)
        {
            return todoOk;
        }
        if(largoArray > 0)
        {
            fprintf(file, "ID_Cachorro,Nombre,Dias,Raza,Reservado,Genero\n");
            for(i=0; i < largoArray; i++)
            {
                auxCachorro = (eCachorro*) ll_get(pArrayListCachorro, i);
                if(auxCachorro != NULL)
                {
                    fprintf(file, "%d,%s,%d,%s,%s,%c\n", auxCachorro->id, auxCachorro->nombre, auxCachorro->dias, auxCachorro->raza, auxCachorro->reservado, auxCachorro->genero);
                }
                else
                {
                    break;
                }
            }
            if(i == largoArray)
            {
                todoOk = 1;
            }
        }
        fclose(file);
    }
    return todoOk;
}

