#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "LinkedList.h"
#include "Cachorro.h"
#include "menu.h"
#include "Controller.h"

int main()
{
    char salir = 'n';
    int flag = 0;
    int cantidadCachorros = 0;
    char nombreArchivo[20];
    LinkedList* listaCachorros = ll_newLinkedList();
    LinkedList* listaMenos45 = ll_newLinkedList();
    LinkedList* listaMachos = ll_newLinkedList();
    LinkedList* listaCallejeros = ll_newLinkedList();
     do{
        switch(menu())
        {
            case 1:
                if(!flag)
                {
                    printf("Ingrese el nombre del archivo: ");
                    fflush(stdin);
                    gets(nombreArchivo);
                    while(strcmp(nombreArchivo, "cachorros.csv") != 0)
                    {
                        printf("Ingrese el nombre del archivo: ");
                        fflush(stdin);
                        gets(nombreArchivo);
                    }
                    cantidadCachorros = controller_loadFromText(nombreArchivo, listaCachorros);
                    if(cantidadCachorros > 0)
                    {
                        printf("\nSe cargaron en el sistema %d cachorros.\n\n", cantidadCachorros);
                        flag = 1;
                    }
                    else
                    {
                        printf("\nNo se pudo cargar ningun cachorro.\n\n");
                    }
                }
                else
                {
                    printf("\nYa se cargaron los cachorros anteriormente.\n\n");
                }
                break;

            case 2:
                controller_ListCachorro(listaCachorros);
                break;

            case 3:
                if(!ll_isEmpty(listaCachorros))
                {
                    listaMenos45 = ll_filter(listaCachorros, filtroDias, "45");

                    if(controller_saveAsText("menosDe45.csv", listaMenos45))
                    {
                         printf("\nCachorros de menos de 45 dias guardados correctamente en modo texto.\n\n");

                         controller_ListCachorro(listaMenos45);
                    }
                    else
                    {
                        printf("\nNo se guardaron los Cachorros de menos de 45 dias.\n\n");
                    }
                }
                else
                {
                    printf("\nNo hay cachorros en el sistema.\n\n");
                }
                break;

            case 4:
                if(!ll_isEmpty(listaCachorros))
                {
                    listaMachos = ll_filter(listaCachorros, filtroMacho, 'M');
                    if(controller_saveAsText("machos.csv", listaMachos))
                    {
                         printf("\nCachorros machos guardados correctamente en modo texto.\n\n");
                         controller_ListCachorro(listaMachos);
                    }
                    else
                    {
                        printf("\nNo se guardaron los cachorros machos.\n\n");
                    }
                }
                else
                {
                    printf("\nNo hay cachorros en el sistema.\n\n");
                }

                break;


            case 5:
                if(!ll_isEmpty(listaCachorros))
                {
                    listaCallejeros = ll_filter(listaCachorros, filtroCallejero, "Callejero");
                    controller_ListCachorro(listaCallejeros);
                }
                else
                {
                    printf("\nNo hay cachorros en el sistema.\n\n");
                }
                break;


            case 6:
                printf("\nDesea salir?(s/n): ");
                fflush(stdin);
                salir = getche();
                while(salir != 's' && salir != 'n')
                {
                    printf("\nError. Ingrese s o n: ");
                    fflush(stdin);
                    salir = getche();
                }
                printf("\n\n");
                break;
        }

        system("pause");

    }while(salir == 'n');

    return 0;


}
