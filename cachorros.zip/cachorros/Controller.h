int controller_loadFromText(char* path , LinkedList* pArrayListCachorro);
int controller_ListCachorro(LinkedList* pArrayListCachorro);
int controller_saveAsText(char* path , LinkedList* pArrayListCachorro);
