#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Cachorro.h"

/** \brief Parsea los datos los datos de los cachorros desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListCachorro LinkedList*
 * \return int Retorna la cantidad de cachorros que se cargaron
 *
 */
int parser_CachorroFromText(FILE* pFile , LinkedList* pArrayListCachorro)
{
    int contador = 0;
    int cantidad = 0;
    char buffer[6][20];
    eCachorro* auxCachorro;

    if(pFile == NULL || pArrayListCachorro == NULL)
    {
        printf("El archivo no existe o no se pudo conseguir memoria.\n");
        exit(EXIT_FAILURE);
    }

    while(!feof(pFile))
    {
        cantidad = fscanf(pFile, "%[^,],%[^,],%[^,],%[^,],%[^,],%[^\n]\n", buffer[0], buffer[1], buffer[2], buffer[3], buffer[4], buffer[5]);
        if(cantidad < 6)
        {
            break;
        }
        else
        {
            auxCachorro = cachorro_newParametros(buffer[0], buffer[1], buffer[2], buffer[3], buffer[4], buffer[5]);

            if(auxCachorro != NULL && ll_len(pArrayListCachorro) < 500)
            {
                if(ll_add(pArrayListCachorro, (eCachorro*)auxCachorro) == 0)
                {
                    contador++;
                }
            }

        }
    }

    return contador;
}

