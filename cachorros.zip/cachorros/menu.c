#include <stdlib.h>
#include <stdio.h>
#include "validaciones.h"

/** \brief Muestra y nos da a elegir una opcion del menu
 *
 * \return int Retorna la opcion elegida
 *
 */
int menu()
{
    char opcionChar[2];
    int opcion;

    system("cls");
    printf("************************** CACHORROS **************************\n\n");
    printf("1- Cargar archivos\n");
    printf("2- Imprimir lista\n");
    printf("3- Filtrar menores de 45 dias\n");
    printf("4- Filtrar machos\n");
    printf("5- Generar callejeros\n");
    printf("6- Salir\n");
    printf("\nIngrese opcion: ");
    fflush(stdin);
    scanf("%s", opcionChar);
    while(!esNumerico(opcionChar) || atoi(opcionChar) < 0 || atoi(opcionChar) > 10)
    {
        printf("Error. Intente nuevamente: ");
        fflush(stdin);
        scanf("%s", opcionChar);
    }

    opcion = atoi(opcionChar);

    return opcion;
}
