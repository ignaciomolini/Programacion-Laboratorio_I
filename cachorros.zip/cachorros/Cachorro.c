#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Cachorro.h"
#include "LinkedList.h"

/** \brief Busca espacio en memoria para una estructura de e inicializa los valores de la misma
 *
 * \return eCachorro* Retorna un puntero a eCachorro
 *
 */
eCachorro* cachorro_new()
{
    eCachorro* nuevo = (eCachorro*) malloc(sizeof(eCachorro));

    if(nuevo != NULL)
    {
        nuevo->id = 0;
        strcpy(nuevo->nombre, " ");
        nuevo->dias = 0;
        strcpy(nuevo->raza, " ");
        strcpy(nuevo->reservado, " ");
        nuevo->genero = ' ';
    }

    return nuevo;
}

/** \brief Carga los valores que se le pasan por parametro a una nueva estructura de cachorro
 *
 * \param idSt char* Direccion de memoria del id
 * \param dominioStr char* Direccion de memoria del domino
 * \param anioStr char* Direccion de memoria del anio
 * \param tipoStr char* Direccion de memoria del tipo
 * \return eCachorro* Retorna un puntero a eCachorro
 *
 */
eCachorro* cachorro_newParametros(char* idStr, char* nombreStr, char* diasStr, char* razaStr, char* reservadoStr, char* generoStr)
{
    eCachorro* nuevo = cachorro_new();

    if(nuevo != NULL)
    {
        if(!cachorro_setId(nuevo, atoi(idStr)) || !cachorro_setNombre(nuevo, nombreStr) ||
           !cachorro_setDias(nuevo, atoi(diasStr)) || !cachorro_setRaza(nuevo, razaStr) ||
           !cachorro_setReservado(nuevo, reservadoStr) || !cachorro_setGenero(nuevo, generoStr[0]))
        {
            free(nuevo);
            nuevo = NULL;
        }
    }

    return nuevo;
}


/** \brief Carga en la estructura  de cachorros el id que se le pasa por parametro
 *
 * \param this eCachorro* Direccion de memoria de la estructura
 * \param id int Valor del id
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int cachorro_setId(eCachorro* this, int id)
{
    int todoOk = 0;

    if(this != NULL && id > 0 && id <= 500)
    {
        this->id = id;
        todoOk = 1;
    }

    return todoOk;
}

/** \brief Carga en el lugar donde apunta la direccion de memoria que se le pasa el valor de la estructura
 *
 * \param this eCachorro* Direccion de memoria de la estructura
 * \param id int* Direccion de memoria del id
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int cachorro_getId(eCachorro* this, int* id)
{
    int todoOk = 0;

    if(this != NULL && id != NULL)
    {
        *id = this->id;
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en la estructura  de dominio el dominio que se le pasa por parametro
 *
 * \param this eCachorro* Direccion de memoria de la estructura
 * \param dominio char* Direccion de memoria de la dominio
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int cachorro_setNombre(eCachorro* this, char* nombre)
{
    int todoOk = 0;

    if(this != NULL && nombre != NULL)
    {
        strcpy(this->nombre, nombre);
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en el lugar donde apunta la direccion de memoria que se le pasa el valor de la estructura
 *
 * \param this eCachorro* Direccion de memoria de la estructura
 * \param dominio char* Direccion de memoria de la dominio
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int cachorro_getNombre(eCachorro* this, char* nombre)
{
    int todoOk = 0;

    if(this != NULL && nombre != NULL)
    {
        strcpy(nombre, this->nombre);
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en la estructura  de dominio el anio que se le pasa por parametro
 *
 * \param this eCachorro* Direccion de memoria de la estructura
 * \param anio int Nombre del anio
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int cachorro_setDias(eCachorro* this, int dias)
{
    int todoOk = 0;

    if(this != NULL && dias >= 0)
    {
        this->dias = dias;
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en el lugar donde apunta la direccion de memoria que se le pasa el valor de la estructura
 *
 * \param this eCachorro* Direccion de memoria de la estructura
 * \param anio int* Direccion de memoria del anio
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int cachorro_getDias(eCachorro* this, int* dias)
{
    int todoOk = 0;

    if(this != NULL && dias != NULL)
    {
        *dias = this->dias;
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en la estructura  de dominio el tipo que se le pasa por parametro
 *
 * \param this eCachorro* Direccion de memoria de la estructura
 * \param tipo char Valor del tipo
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int cachorro_setRaza(eCachorro* this, char* raza)
{
    int todoOk = 0;

    if(this != NULL && raza != NULL)
    {
        strcpy(this->raza, raza);
        todoOk = 1;
    }

    return todoOk;
}

/** \brief Carga en el lugar donde apunta la direccion de memoria que se le pasa el valor de la estructura
 *
 * \param this eCachorro* Direccion de memoria de la estructura
 * \param tipo char* Direccion de memoria del tipo
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int cachorro_getRaza(eCachorro* this, char* raza)
{
    int todoOk = 0;

    if(this != NULL && raza != NULL)
    {
        strcpy(raza, this->raza);
        todoOk = 1;
    }

    return todoOk;
}



int cachorro_setReservado(eCachorro* this, char* reservado)
{
    int todoOk = 0;

    if(this != NULL && reservado != NULL)
    {
        strcpy(this->reservado, reservado);
        todoOk = 1;
    }

    return todoOk;
}


int cachorro_getReservado(eCachorro* this, char* reservado)
{
    int todoOk = 0;

    if(this != NULL && reservado != NULL)
    {
        strcpy(reservado, this->reservado);
        todoOk = 1;
    }

    return todoOk;
}

int cachorro_setGenero(eCachorro* this, char genero)
{
    int todoOk = 0;

    if(this != NULL)
    {
        this->genero = genero;
        todoOk = 1;
    }

    return todoOk;
}


int cachorro_getGenero(eCachorro* this, char* genero)
{
    int todoOk = 0;

    if(this != NULL && genero != NULL)
    {
        *genero = this->genero;
        todoOk = 1;
    }

    return todoOk;
}

/** \brief Muestra el dominio pasado por parametro
 *
 * \param this eCachorro* Puntero a la estructura eCachorro
 *
 */
void mostrarCachorro(eCachorro* this)
{
    printf("| %3d |   %10s  |  %4d  |   %10s  |  %2s  |  %c  |\n", this->id, this->nombre, this->dias, this->raza, this->reservado, this->genero);
}


/** \brief Muestra todos elementos de la lista
 *
 * \param this LinkedList* Puntero al LinkedList
 * \return int Retorna la cantidad de elementos mostrados
 *
 */
int mostrarCachorros(LinkedList* this)
{
    int cantidad = 0;
    int tam;

    if(this != NULL)
    {
        tam = ll_len(this);

        printf("\n|  Id |     Nombre    |  Dias  |      Raza     |  Res | Gen |\n");
        printf("----------------------------------------------------------------------\n");

        for(int i=0; i<tam; i++)
        {
            mostrarCachorro(((eCachorro*) ll_get(this, i)));
            cantidad++;
        }
    }

    return cantidad;
}


/** \brief Me dice si el elemento tiene el mismo tipo que le paso por parametro
 *
 * \param pElement void* Puntero al elemento
 * \param charTipo char Caracter tipo
 * \return int Retorna 1 si es del mismo tipo y 0 si no lo es
 *
 */
 int filtroDias(void* pElement, char charTipo[])
{
    int ret = -1;
    int dias;

    if(pElement != NULL)
    {
        dias = ((eCachorro*) pElement)->dias;

        if(dias >= atoi(charTipo))
        {
            ret = 1;
        }
        else
        {
            ret = 0;
        }
    }

    return ret;
}

 int filtroMacho(void* pElement, char charTipo)
{
    int ret = -1;
    char genero;

    if(pElement != NULL)
    {
        genero = ((eCachorro*) pElement)->genero;

        if(genero != charTipo)
        {
            ret = 1;
        }
        else
        {
            ret = 0;
        }
    }

    return ret;
}

 int filtroCallejero(void* pElement, char charTipo[])
{
    int ret = -1;
    char raza[20];

    if(pElement != NULL)
    {
        strcpy(raza, ((eCachorro*) pElement)->raza);

        if(strcmp(raza, charTipo) == 0)
        {
            ret = 1;
        }
        else
        {
            ret = 0;
        }
    }

    return ret;
}




