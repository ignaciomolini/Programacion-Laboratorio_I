int parser_CachorroFromText(FILE* pFile , LinkedList* pArrayListCachorro);
