#include "Clientes.h"
#include "Alquileres.h"

int menuInformes();
void mostrarJuegosMesa(eJuego juegos[], int tamJ, eCategoria categorias[], int tamCat, char desc[]);
void mostrarInformes(eCliente clientes[], int tamC, eAlquiler alquileres[], int tamAl, eJuego juegos[], int tamJ, eCategoria categorias[], int tamCat, eLocalidad localidades[], int tamLoc);
int mostrarAlquileresDeCliente(eCliente clientes[], int tamC, eAlquiler alquileres[], int tamAl, eJuego juegos[], int tamJ, eLocalidad localidades[], int tamLoc);
int mostrarImporteDeCliente(eCliente clientes[], int tamC, eAlquiler alquileres[], int tamAl, eJuego juegos[], int tamJ, eLocalidad localidades[], int tamLoc);
int mostrarClientesSinAlquiler(eCliente clientes[], int tamC, eAlquiler alquileres[], int tamAl, eLocalidad localidades[], int tamLoc);
void mostrarJuegosNoAlquilados(eAlquiler alquileres[], int tamAl, eJuego juegos[], int tamJ);
void clientesDeLocalidad(eCliente clientes[],int tamC, eLocalidad localidades[],int tamLoc);
void mostrarFechaYNombreDeAlquilerDeJuego(eAlquiler alquileres[], int tamAl, eCliente clientes[], int tamC, eJuego juegos[], int tamJ);
void mostrarClientesDeUnJuego(eAlquiler alquileres[], int tamAl, eCliente clientes[], int tamC, eJuego juegos[], int tamJ, eLocalidad localidades[], int tamLoc);
void mostrarJuegosAlquiladosPorMujeres(eAlquiler alquileres[], int tamAl, eCliente clientes[], int tamC, eJuego juegos[], int tamJ);
