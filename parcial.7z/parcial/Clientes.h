#ifndef CLIENTES_H_INCLUDED
#define CLIENTES_H_INCLUDED

typedef struct
{
    int id;
    char nombre[51];
    char apellido[51];
    char sexo;
    int telefono;
    char domicilio[51];
    int isEmpty;

}eCliente;

#endif // CLIENTES_H_INCLUDED

void mostrarCliente(eCliente cl);
void mostrarClientes(eCliente vec[], int tamC);
void inicializarClientes(eCliente vec[], int tam);
int buscarLibre(eCliente vec[], int tamC);
int buscarCliente(int id, eCliente vec[], int tamC);
int altaCliente(eCliente vec[], int tamC, int id);
eCliente newCliente(int id, char nombre[], char apellido[], char sexo,int telefono, char domicilio[]);
int modificarCliente(eCliente vec[], int tamC);
int bajaCliente(eCliente vec[], int tamC);
void ordenarClientes(eCliente vec[], int tamC);
