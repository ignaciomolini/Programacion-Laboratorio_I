#ifndef CLIENTES_H_INCLUDED
#define CLIENTES_H_INCLUDED

typedef struct
{
    int id;
    char nombre[51];

}eLocalidad;

typedef struct
{
    int id;
    char nombre[51];
    char apellido[51];
    char sexo;
    int telefono;
    char domicilio[51];
    int idLocalidad;
    int isEmpty;

}eCliente;

#endif // CLIENTES_H_INCLUDED

void mostrarLocalidades(eLocalidad localidades[], int tamLoc);
int cargarDescLocalidad(int idLocalidad, eLocalidad localidades[], int tamLoc, char desc[]);
void mostrarCliente(eCliente cl, eLocalidad localidades[], int tamLoc);
int mostrarClientes(eCliente vec[], int tamC, eLocalidad localides[], int tamLoc);
void inicializarClientes(eCliente vec[], int tamC);
int buscarLibre(eCliente vec[], int tamC);
int buscarCliente(int id, eCliente vec[], int tamC);
int altaCliente(eCliente vec[], int tamC, int id, eLocalidad localidades[], int tamLoc);
eCliente newCliente(int id, char nombre[], char apellido[], char sexo, int telefono, char domicilio[], int loc);
int modificarCliente(eCliente vec[], int tamC, eLocalidad localidades[], int tamLoc);
int bajaCliente(eCliente vec[], int tamC, eLocalidad localidades[], int tamLoc);
void ordenarClientes(eCliente vec[], int tamC);
int hardcodearClientes(eCliente vec[], int tamC, int cantidad);
