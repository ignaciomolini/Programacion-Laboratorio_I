#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "Clientes.h"
#include "Validaciones.h"

/** \brief Muestra los datos de las localidades
 *
 * \param localidades[] eLocalidad Vector de estructuras eLocalidad
 * \param tamLoc int Tama�o del vector
 *
 */
void mostrarLocalidades(eLocalidad localidades[], int tamLoc)
{
    for(int i=0; i < tamLoc; i++)
    {
        printf("%d    %s\n", localidades[i].id, localidades[i].nombre);
    }
}

/** \brief Se copia el nombre de la localidad del id que se pasa
 *
 * \param idLocalidad int Valor del id de la localidad
 * \param localidades[] eLocalidad Vector de estructuras eLocalidad
 * \param tamLoc int Tama�o del vector
 * \param desc[] char Cadena de caracteres
 * \return Retorna 1 se copio y 0 si no
 *
 */
int cargarDescLocalidad(int idLocalidad, eLocalidad localidades[], int tamLoc, char desc[])
{
    int todoOk = 0;

    for(int i=0; i < tamLoc; i++)
    {
        if(idLocalidad == localidades[i].id)
        {
            strcpy(desc, localidades[i].nombre);
            todoOk = 1;
            break;
        }
    }
    return todoOk;
}


/** \brief Muestra los datos del cliente en la posicion que se le pasa
 *
 * \param cl eCliente Una estructura del vector de estructuras eCliente
 *
 */
void mostrarCliente(eCliente cl, eLocalidad localidades[], int tamLoc)
{
    char desc[51];
    cargarDescLocalidad(cl.idLocalidad, localidades, tamLoc, desc);
    printf("  %3d   %10s   %10s     %c     %5d     %10s     %10s\n", cl.id, cl.nombre, cl.apellido, cl.sexo, cl.telefono, cl.domicilio, desc);
}


/** \brief Muestra los datos del vector de estructuras eCliente
 *
 * \param vec[] eCliente Vector de estructuras eCliente
 * \param tamC int Tama�o del vector
 * \return Retorna 1 si hay clientes y 0 si no hay ninguno
 *
 */
int mostrarClientes(eCliente vec[], int tamC, eLocalidad localides[], int tamLoc)
{
    int flag = 0;

    ordenarClientes(vec, tamC);

    printf(" Codigo      Nombre     Apellido   Sexo    Telefono     Domicilio     Localidad\n\n");

    for(int i=0; i < tamC; i++)
    {
        if( vec[i].isEmpty == 0)
        {
            mostrarCliente(vec[i], localides, tamLoc);
            flag = 1;
        }
    }

    if( flag == 0)
    {
        system("cls");
        printf("\nNo hay clientes que mostrar\n");
    }

    printf("\n");

    return flag;
}


/** \brief Ordena el vector de estrucutas eCliente primero por apellido y luego por nombre
 *
 * \param vec[] eCliente Vector de estructuras eCliente
 * \param tamC int Tama�o del vector
 *
 */
void ordenarClientes(eCliente vec[], int tamC)
{
    eCliente auxCliente;

    for(int i=0; i < tamC-1 ; i++)
    {
        for(int j=i+1; j <tamC; j++)
        {
            if((strcmp(vec[i].apellido, vec[j].apellido)) > 0)
            {
                auxCliente = vec[i];
                vec[i] = vec[j];
                vec[j] = auxCliente;
            }
            else if((strcmp(vec[i].apellido, vec[j].apellido)) == 0 && (strcmp(vec[i].nombre, vec[j].nombre)) > 0)
            {
                auxCliente = vec[i];
                vec[i] = vec[j];
                vec[j] = auxCliente;
            }
        }
    }
}


/** \brief Carga en el valor isEmpty de todas las estrucutas de vector eCliente un 1 indicando
 *         que estan vacias
 * \param vec[] eCliente Vector de estructuras eCliente
 * \param tamC int Tama�o del vector
 *
 */
void inicializarClientes(eCliente vec[], int tamC)
{
    for(int i = 0; i < tamC; i++)
    {
        vec[i].isEmpty = 1;
    }
}


/** \brief Busca si hay una estructura vacia dentro del vector
 *
 * \param vec[] eCliente Vector de estructuras eCliente
 * \param tamC int Tama�o del vector
 * \return Retorna el el indice del vector donde hay una estructura vacia
 *
 */
int buscarLibre(eCliente vec[], int tamC)
{
    int indice = -1;

    for(int i=0; i < tamC; i++)
    {
        if( vec[i].isEmpty == 1 )
        {
            indice = i;
            break;
        }
    }
    return indice;
}


/** \brief Busca un cliente con igual id al que se le paso y que no este dado de baja
 *
 * \param id int Id del cliente
 * \param vec[] eCliente Vector de estructuras eCliente
 * \param tamC int Tama�o del vector
 * \return Retorna el indice del vector donde se encuentra la estructura con igual id que se le paso
 *
 */
int buscarCliente(int id, eCliente vec[], int tamC)
{
    int indice = -1;

    for(int i=0; i < tamC; i++)
    {
        if( vec[i].id == id && vec[i].isEmpty == 0)
        {
            indice = i;
            break;
        }
    }
    return indice;
}


/** \brief Se cargan los valores de la estructura eCliente
 *
 * \param vec[] eCliente Vector de estructuras eCliente
 * \param tamC int Tama�o del vector
 * \param id int Id del cliente
 * \return Retorna 0 si se concreto el alta
 *
 */
int altaCliente(eCliente vec[], int tamC, int id, eLocalidad localidades[], int tamLoc)
{
    int todoOk = 0;
    int indice;
    char nombre[51];
    char apellido[51];
    char sexo;
    char auxTelefono[21];
    int telefono;
    char domicilio[51];
    int loc;

    system("cls");

    printf("*****Alta Cliente*****\n\n");

    indice = buscarLibre(vec, tamC);

    if( indice == -1)
    {
        printf("\nSistema completo\n\n");
    }
    else
    {
        printf("Ingrese nombre: ");
        fflush(stdin);
        gets(nombre);
        while(!validarNombre(nombre))
        {
            printf("Error. Ingrese nombre: ");
            fflush(stdin);
            gets(nombre);
        }

        printf("Ingrese apellido: ");
        fflush(stdin);
        gets(apellido);
        while(!validarNombre(apellido))
        {
            printf("Error. Ingrese apellido: ");
            fflush(stdin);
            gets(apellido);
        }

        printf("Ingrese sexo: ");
        fflush(stdin);
        scanf("%c", &sexo);
        while(sexo != 'f' && sexo != 'm')
        {
            printf("Error. Ingrese sexo(f/m): ");
            fflush(stdin);
            scanf("%c", &sexo);
        }

        printf("Ingrese telefono: ");
        fflush(stdin);
        gets(auxTelefono);
        while(!validarTelefono(auxTelefono))
        {
            printf("Error. Ingrese telefono: ");
            fflush(stdin);
            gets(auxTelefono);
        }
        telefono = atoi(auxTelefono);

        printf("Ingrese domicilio: ");
        fflush(stdin);
        gets(domicilio);
        strlwr(domicilio);
        domicilio[0] = toupper(domicilio[0]);
        for(int i=0; i < strlen(domicilio); i++)
        {
            if(domicilio[i] == ' ')
            {
            domicilio[i+1] = toupper(domicilio[i+1]);
            }
        }
        mostrarLocalidades(localidades, tamLoc);
        printf("Ingrese id de localidad: ");
        scanf("%d", &loc);

        vec[indice] = newCliente(id, nombre, apellido, sexo, telefono, domicilio, loc);
        todoOk = 1;
        printf("Alta exitosa!!\n\n");
    }
    return todoOk;
}


/** \brief Se le pasan los valores y se cargan en la estructura
 *
 * \param id int Valor del id del cliente
 * \param nombre[] char Nombre del cliente
 * \param apellido[] char Apellido del cliente
 * \param sexo char Sexo del ciente
 * \param telefono int Numero de telefono del cliente
 * \param domicilio[] char Domicilio del cliente
 * \return Retorna la estructura con los datos cargados
 *
 */
eCliente newCliente(int id, char nombre[], char apellido[], char sexo, int telefono, char domicilio[], int loc)
{
    eCliente cl;

    cl.id = id;
    strcpy(cl.nombre, nombre);
    strcpy(cl.apellido, apellido);
    cl.sexo = sexo;
    cl.telefono = telefono;
    strcpy(cl.domicilio, domicilio);
    cl.idLocalidad = loc;
    cl.isEmpty = 0;

    return cl;
}


/** \brief  Mediante el ingreso del id del cliente se pueden modificar los datos(nombre-domicilio-telefono)
 *
 * \param vec[] eCliente Vector de estructuras eCliente
 * \param tamC int Tama�o del vector
 * \return Retorna 0 si no hubo ningun problema y un 1 si no hay clientes
 *
 */
int modificarCliente(eCliente vec[], int tamC, eLocalidad localidades[], int tamLoc)
{
    int todoOk = 0;
    int id;
    int indice;
    char auxTelefono[21];

    system("cls");
    printf("***** Modificar Cliente *****\n\n");
    if(!mostrarClientes(vec, tamC, localidades, tamLoc))
    {
        system("cls");
        printf("***** Modificar Cliente *****\n\n");
        printf("No hay clientes por modificar\n\n");
        return todoOk = 1;
    }
    printf("Ingrese id de cliente: ");
    scanf("%d", &id);
    int opcion;

    indice = buscarCliente(id, vec, tamC);

    if( indice == -1)
    {
        printf("\nNo existe un cliente con ese id\n\n");
    }
    else
    {

        printf("\n");
        mostrarCliente(vec[indice], localidades, tamLoc);
        printf("\n");

        printf("1- Modificar nombre\n");
        printf("2- Modificar domicilio\n");
        printf("3- Modificar telefono\n");
        printf("4- Salir\n\n");
        printf("Ingrese opcion: ");
        scanf("%d", &opcion);

        switch(opcion)
        {
        case 1:
            printf("\nIngrese nuevo nombre: ");
            fflush(stdin);
            gets(vec[indice].nombre);
            while(!validarNombre(vec[indice].nombre))
            {
                printf("Error. Ingrese nuevo nombre: ");
                fflush(stdin);
                gets(vec[indice].nombre);
            }
            printf("\n");
            break;

        case 2:
            printf("Ingrese nuevo domicilio: ");
            fflush(stdin);
            gets(vec[indice].domicilio);
            strlwr(vec[indice].domicilio);
            vec[indice].domicilio[0] = toupper(vec[indice].domicilio[0]);
            for(int i=0; i < strlen(vec[indice].domicilio); i++)
            {
                if(vec[indice].domicilio[i] == ' ')
                {
                vec[indice].domicilio[i+1] = toupper(vec[indice].domicilio[i+1]);
                }
            }
            printf("\n");
            break;

        case 3:
            printf("\nIngrese nuevo telefono: ");
            fflush(stdin);
            gets(auxTelefono);
            while(!validarTelefono(auxTelefono))
            {
                printf("Error. Ingrese nuevo telefono: ");
                fflush(stdin);
                gets(auxTelefono);
            }
            vec[indice].telefono = atoi(auxTelefono);
            printf("\n");
            break;

        case 4:
            printf("\nSe ha cancelado la modificacion\n\n");
            break;

        }
    }
    return todoOk;
}


/** \brief Se realiza una baja logica dandole valor 1 a isEmpty
 *
 * \param vec[] eCliente Vector de estructuras eCliente
 * \param tamC int Tama�o del vector
 * \return Retorna 0 si no hubo problemas y un 1 si no hay clientes
 *
 */
int bajaCliente(eCliente vec[], int tamC, eLocalidad localidades[], int tamLoc)
{
    int todoOk = 0;
    int id;
    int indice;
    char confirma;

    system("cls");
    printf("***** Baja Cliente *****\n\n");
    if(!mostrarClientes(vec, tamC, localidades, tamLoc))
    {
        system("cls");
        printf("***** Baja Cliente *****\n\n");
        printf("No hay clientes por dar de baja\n\n");
        return todoOk = 1;
    }
    printf("Ingrese codigo de cliente: ");
    scanf("%d", &id);
    printf("\n");

    indice = buscarCliente(id, vec, tamC);

    if( indice == -1)
    {
        printf("No existe un cliente con ese codigo\n\n");
    }
    else
    {
        mostrarCliente(vec[indice], localidades, tamLoc);

        printf("\nConfirma baja? ");
        fflush(stdin);
        scanf("%c", &confirma);

        if( confirma == 's')
        {
            vec[indice].isEmpty = 1;
            todoOk = 1;
            printf("\nBaja exitosa!!!\n\n");
        }
        else
        {
            printf("\nSe ha cancelado la operacion\n\n");
        }
    }

    return todoOk;
}


/** \brief Se utiliza para probar el funcionamiento del programa, dandole
 *         los datos cargados de algunos clientes
 * \param vec[] eCliente Vector de estructuras eCliente
 * \param tamC int Tama�o del vector
 * \param cantidad int Cantidad de clientes que van a utilizar
 * \return Retorna la cantidad de clientes que se utulizaron
 *
 */
int hardcodearClientes(eCliente vec[], int tamC, int cantidad)
{
    int contador = 0;

    eCliente suplentes[] =
    {
        { 1000, "Juan", "Perez", 'm', 42414857, "Gorriti 334", 300},
        { 1001, "Alberto", "Perez", 'm', 42422357, "Freire 5634", 302},
        { 1002, "Ana", "Diaz", 'f', 42453457, "Murguiondo 496", 301},
        { 1003, "Luis", "Perez", 'm', 42492344, "Moreno 2334", 303},
        { 1004, "Alicia", "Alvarez", 'f', 42254355, "Jujuy 256", 301},
        { 1005, "Diego", "Diaz", 'm', 39343857, "Mitre 4439", 304},
        { 1006, "Sofia", "Perez", 'f', 42253243, "Sarmiento 5432", 302},
        { 1007, "Clara", "Alvarez", 'f', 42412314, "Noya 122", 300},
        { 1008, "Mauro", "Perez", 'm', 42474555, "Tejedor 576", 303},
        { 1009, "Daniela", "Rodriguez", 'f', 42434399, "Iberlucea 299", 304},
        { 1010, "Agustin", "Perez", 'm', 42252112, "Pichincha 1476", 302},
    };

    if(cantidad <= 10 && tamC >= cantidad)
    {
        for(int i=0; i < cantidad; i++)
        {
            vec[i] = suplentes[i];
            contador++;
        }
    }

    return contador;
}
