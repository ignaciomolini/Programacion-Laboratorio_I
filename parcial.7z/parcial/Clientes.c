#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "Clientes.h"

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

void mostrarCliente(eCliente cl)
{
    printf(" %d   %s   %s   %c   %d   %s\n", cl.id, cl.nombre, cl.apellido, cl.sexo, cl.telefono, cl.domicilio);
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

void mostrarClientes(eCliente vec[], int tamC)
{
    int flag = 0;
    system("cls");

    ordenarClientes(vec, tamC);

    printf(" Codigo     Nombre     Apellido   Sexo    Telefono     Domicilio\n\n");

    for(int i=0; i < tamC; i++)
    {
        if( vec[i].isEmpty == 0)
        {
            mostrarCliente(vec[i]);
            flag = 1;
        }
    }

    if( flag == 0)
    {
        printf("\nNo hay clientes que mostrar\n");
    }

    printf("\n\n");
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

void ordenarClientes(eCliente vec[], int tamC)
{
    eCliente auxCliente;

    for(int i=0; i < tamC-1 ; i++)
    {
        for(int j=i+1; j <tamC; j++)
        {
            if((strcmp(vec[i].apellido, vec[j].apellido)) > 0)
            {
                auxCliente = vec[i];
                vec[i] = vec[j];
                vec[j] = auxCliente;
            }
            else if((strcmp(vec[i].apellido, vec[j].apellido)) == 0 && (stricmp(vec[i].nombre, vec[j].nombre)) > 0)
            {
                auxCliente = vec[i];
                vec[i] = vec[j];
                vec[j] = auxCliente;
            }
        }
    }
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

void inicializarClientes(eCliente vec[], int tam)
{
    for(int i = 0; i < tam; i++)
    {
        vec[i].isEmpty = 1;
    }
}


/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int buscarLibre(eCliente vec[], int tamC)
{
    int indice = -1;

    for(int i=0; i < tamC; i++)
    {
        if( vec[i].isEmpty == 1 )
        {
            indice = i;
            break;
        }
    }
    return indice;
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int buscarCliente(int id, eCliente vec[], int tamC)
{
    int indice = -1;

    for(int i=0; i < tamC; i++)
    {
        if( vec[i].id == id && vec[i].isEmpty == 0)
        {
            indice = i;
            break;
        }
    }
    return indice;
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int altaCliente(eCliente vec[], int tamC, int id)
{
    int todoOk = 0;
    int indice;
    char nombre[51];
    char apellido[51];
    char sexo;
    char auxTelefono[21];
    int telefono;
    char domicilio[51];

    system("cls");

    printf("*****Alta Cliente*****\n\n");

    indice = buscarLibre(vec, tamC);

    if( indice == -1)
    {
        printf("\nSistema completo\n\n");
    }
    else
    {
        printf("Ingrese nombre: ");
        fflush(stdin);
        gets(nombre);
        while(strlen(nombre) > 51)
        {
            printf("\nError. Ingrese nombre: ");
            fflush(stdin);
            gets(nombre);
        }

        printf("Ingrese apellido: ");
        fflush(stdin);
        gets(apellido);
        while(strlen(nombre) > 51)
        {
            printf("\nError. Ingrese nombre: ");
            fflush(stdin);
            gets(nombre);
        }

        printf("Ingrese sexo: ");
        fflush(stdin);
        scanf("%c", &sexo);
        while(sexo != 'f' && sexo != 'm')
        {
            printf("\nError. Ingrese sexo(f/m): ");
            fflush(stdin);
            scanf("%c", &sexo);
        }

        printf("Ingrese telefono: ");
        fflush(stdin);
        gets(auxTelefono);
        while(strlen(auxTelefono) > 21)
        {
            printf("Error. Ingrese telefono: ");
            fflush(stdin);
            gets(auxTelefono);
        }
        telefono = atoi(auxTelefono);

        printf("Ingrese domicilio: ");
        fflush(stdin);
        gets(domicilio);

        vec[indice] = newCliente(id, nombre, apellido, sexo, telefono, domicilio);
        todoOk = 1;
        printf("Alta exitosa!!\n\n");
    }

    return todoOk;
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

eCliente newCliente(int id, char nombre[], char apellido[], char sexo,int telefono, char domicilio[])
{
    eCliente cl;

    cl.id = id;
    strcpy(cl.nombre, nombre);
    strcpy(cl.apellido, apellido);
    cl.sexo = sexo;
    cl.telefono = telefono;
    strcpy(cl.domicilio, domicilio);
    cl.isEmpty = 0;

    return cl;
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int modificarCliente(eCliente vec[], int tamC)
{

    int todoOk = 0;
    int id;
    int indice;
    system("cls");
    printf("***** Modificar Cliente *****\n\n");
    printf("Ingrese codigo de cliente: ");
    scanf("%d", &id);
    int opcion;

    indice = buscarCliente(id, vec, tamC);

    if( indice == -1)
    {
        printf("No existe un cliente con ese id\n\n");

    }
    else
    {

        mostrarCliente(vec[indice]);

        printf("1- Modificar nombre\n");
        printf("2- Modificar domicilio\n");
        printf("3- Modificar telefono\n");
        printf("4- Salir\n\n");
        printf("Ingrese opcion: ");
        scanf("%d", &opcion);

        switch(opcion)
        {
        case 1:
            printf("Ingrese nueva nombre: ");
            fflush(stdin);
            gets(vec[indice].nombre);
            break;

        case 2:
            printf("Ingrese nuevo domicilio: ");
            fflush(stdin);
            gets(vec[indice].domicilio);
            break;

        case 3:
            printf("Ingrese nuevo telefono: ");
            fflush(stdin);
            scanf("%d", &vec[indice].telefono);
            break;

        case 4:
            printf("Se ha cancelado la modificacion ");
            break;

        }
    }
    return todoOk;
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int bajaCliente(eCliente vec[], int tamC)
{
    int todoOk = 0;
    int id;
    int indice;
    char confirma;
    system("cls");
    printf("***** Baja Cliente *****\n\n");
    printf("Ingrese codigo de cliente: ");
    scanf("%d", &id);

    indice = buscarCliente(id, vec, tamC);

    if( indice == -1)
    {
        printf("No existe un cliente con ese codigo\n\n");

    }
    else
    {
        mostrarCliente(vec[indice]);

        printf("\nConfirma baja?");
        fflush(stdin);
        scanf("%c", &confirma);

        if( confirma == 's')
        {
            vec[indice].isEmpty = 1;
            todoOk = 1;
            printf("Baja exitosa!!!");
        }
        else
        {
            printf("Se ha cancelado la operacion");
        }
    }

    return todoOk;
}

