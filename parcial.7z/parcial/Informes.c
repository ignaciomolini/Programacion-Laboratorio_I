#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "Clientes.h"
#include "Alquileres.h"
#include "Informes.h"


/** \brief Menu de opciones
 *
 * \return Retona la opcion elegida
 *
 */
int menuInformes()
{
    int opcion;
    system("cls");
    printf("****** Informes *******\n\n");
    printf("1-Mostrar Juegos de categoria de mesa\n");
    printf("2-Mostrar los alquileres efectuados por algun cliente seleccionado\n");
    printf("3-Mostrar el total de todos los importes pagados por el cliente seleccionado\n");
    printf("4-Listar los clientes que no alquilaron juegos\n");
    printf("5-Listar los juegos que no han sido alquilados\n");
    printf("6-Listar clientes de un localidad\n");
    printf("7-Listar fecha y nombre de clientes que alquilaron un juego\n");
    printf("8-Listar los clientes que alquilaron determinado juego\n");
    printf("9-Listar los juegos alquilados por mujeres\n");
    printf("10-Salir\n\n");
    printf("Ingrese opcion: ");
    scanf("%d", &opcion);

    return opcion;
}


/** \brief Muestra todos lo informes
 *
 * \param clientes[] eClientes Vector de estruturas eCliente
 * \param tamC int Tama�o del vector eCliente
 * \param alquileres[] eAlquiler Vector de estructura eAlquiler
 * \param tamAl int Tama�o del vector eAlquiler
 * \param juegos[] eJuegos Vector de estruturas eJuegos
 * \param tamJ int Tama�o del vector eJuegos
 * \param categorias[] eCategoria Vector de estructuras eCategoria
 * \param tamCat int Tama�o del vector eCategoria
 *
 */
void mostrarInformes(eCliente clientes[], int tamC, eAlquiler alquileres[], int tamAl, eJuego juegos[], int tamJ, eCategoria categorias[], int tamCat, eLocalidad localidades[], int tamLoc)
{
    char salir = 'n';
    int a;

    do
    {
        switch(a = menuInformes())
        {
        case 1:
            mostrarJuegosMesa(juegos, tamJ, categorias, tamCat, "mesa");
            break;

        case 2:
            mostrarAlquileresDeCliente(clientes, tamC, alquileres, tamAl, juegos, tamJ, localidades, tamLoc);
            break;

        case 3:
            mostrarImporteDeCliente(clientes, tamC, alquileres, tamAl, juegos, tamJ, localidades, tamLoc);
            break;

        case 4:
            mostrarClientesSinAlquiler(clientes, tamC, alquileres, tamAl, localidades, tamLoc);
            break;

        case 5:
            mostrarJuegosNoAlquilados(alquileres, tamAl, juegos, tamJ);
            break;

        case 6:
            clientesDeLocalidad(clientes, tamC, localidades, tamLoc); //1
            break;

        case 7:
            mostrarFechaYNombreDeAlquilerDeJuego(alquileres, tamAl, clientes, tamC, juegos, tamJ); //4
            break;

        case 8:
            mostrarClientesDeUnJuego(alquileres, tamAl, clientes, tamC, juegos, tamJ, localidades, tamLoc); //9
            break;

        case 9:
            mostrarJuegosAlquiladosPorMujeres(alquileres, tamAl, clientes, tamC, juegos, tamJ); //7
            break;

        case 10:
            printf("\nConfirma salir?: ");
            fflush(stdin);
            salir = getche();
            while(salir != 's' && salir != 'n')
            {
                printf("\nError. Ingrese s/n: ");
                fflush(stdin);
                salir = getche();
            }
            printf("\n\n");
            break;

        default:
            printf("\nOpcion Invalida!\n\n");
        }
        if(a != 10)
        {
            system("pause");
        }
    }
    while(salir == 'n');
}


/** \brief Muestra los juegos que son de la categoria "mesa"
 *
 * \param juegos[] eJuegos Vector de estruturas eJuegos
 * \param tamJ int Tama�o del vector eJuegos
 * \param categorias[] eCategoria Vector de estructuras eCategoria
 * \param tamCat int Tama�o del vector eCategoria
 * \param desc[] char Cadena de caracteres con la descripcion
 *
 */
void mostrarJuegosMesa(eJuego juegos[], int tamJ, eCategoria categorias[], int tamCat, char desc[])
{
    int indice = -1;
    system("cls");
    printf("***** Juegos de %s *****\n", desc);

    for(int i=0; i < tamCat; i++)
    {
        if(strcmp(desc, categorias[i].descripcion) == 0)
        {
            indice = i;
            break;
        }
    }

    for(int j=0; j < tamJ; j++)
    {
        if(indice == -1)
        {
            printf("\nNo hay juegos de esa categoria\n");
            break;
        }
        else if(juegos[j].idCategoria == categorias[indice].id)
        {
            printf("\n");
            mostrarJuego(juegos[j]);
        }
    }
    printf("\n");
}


/** \brief Muestra los alquileres que realizo el cliente indicado por su id
 *
 * \param clientes[] eClientes Vector de estruturas eCliente
 * \param tamC int Tama�o del vector eCliente
 * \param alquileres[] eAlquiler Vector de estructura eAlquiler
 * \param tamAl int Tama�o del vector eAlquiler
 * \param juegos[] eJuegos Vector de estruturas eJuegos
 * \param tamJ int Tama�o del vector eJuegos
 * \return Retorna 0 si no hubo problemas y 1 si no hay clientes
 *
 */
int mostrarAlquileresDeCliente(eCliente clientes[], int tamC, eAlquiler alquileres[], int tamAl, eJuego juegos[], int tamJ, eLocalidad localidades[], int tamLoc)
{
    int idCliente;
    int indice;
    int flag = 0;
    system("cls");
    printf("***** Alquileres por cliente seleccionado *****\n\n");
    if(!mostrarClientes(clientes, tamC, localidades, tamLoc))
    {
        system("cls");
        printf("***** Alquileres por cliente seleccionado *****\n\n");
        printf("No hay clientes en el sistema\n\n");
        return 1;
    }
    printf("Ingrese el id cliente: ");
    scanf("%d", &idCliente);

    indice = buscarCliente(idCliente, clientes, tamC);

    if(indice == -1)
    {
        printf("\nNo hay cliente con ese id\n\n");
    }
    else
    {
        for(int i=0; i < tamAl; i++)
        {
            if(alquileres[i].idCliente == idCliente && alquileres[i].isEmpty == 0)
            {
                printf("\n");
                mostrarAlquiler(alquileres[i], juegos, tamJ, clientes, tamC);
                flag = 1;
            }
        }

        if(flag == 0)
        {
            printf("\nEste cliente no realizo ningun alquiler\n\n");
        }
    }
    printf("\n");

    return 0;
}


/** \brief Muestra el total del importe del cliente indicado por su id
 *
 * \param clientes[] eClientes Vector de estruturas eCliente
 * \param tamC int Tama�o del vector eCliente
 * \param alquileres[] eAlquiler Vector de estructura eAlquiler
 * \param tamAl int Tama�o del vector eAlquiler
 * \param juegos[] eJuegos Vector de estruturas eJuegos
 * \param tamJ int Tama�o del vector eJuegos
 * \return Retorna 0 si no hubo problemas y 1 si no hay clientes
 *
 */
int mostrarImporteDeCliente(eCliente clientes[], int tamC, eAlquiler alquileres[], int tamAl, eJuego juegos[], int tamJ, eLocalidad localidades[], int tamLoc)
{
    int idCliente;
    int indice;
    float acumulador = 0;
    system("cls");
    printf("***** Importes por cliente seleccionado *****\n\n");
    if(!mostrarClientes(clientes, tamC, localidades, tamLoc))
    {
        system("cls");
        printf("***** Importes por cliente seleccionado *****\n\n");
        printf("No hay clientes en el sistema\n\n");
        return 1;
    }
    printf("Ingrese el id cliente: ");
    scanf("%d", &idCliente);

    indice = buscarCliente(idCliente, clientes, tamC);

    if(indice == -1)
    {
        printf("\nNo hay cliente con ese id\n\n");
    }
    else
    {
        for(int i=0; i < tamAl; i++)
        {
            if(alquileres[i].idCliente == idCliente && alquileres[i].isEmpty == 0)
            {
                for(int j=0; j < tamJ; j++)
                {
                    if(juegos[j].id == alquileres[i].idJuego)
                    {
                        acumulador += juegos[j].importe;
                        break;
                    }
                }
            }
        }
        printf("\nEl importe del cliente %s, %s es de $%.2f\n\n", clientes[indice].apellido, clientes[indice].nombre, acumulador);
    }
    return 0;
}


/** \brief Muestra los clientes que no realizaron ningun alquiler
 *
 * \param clientes[] eClientes Vector de estruturas eCliente
 * \param tamC int Tama�o del vector eCliente
 * \param alquileres[] eAlquiler Vector de estructura eAlquiler
 * \param tamAl int Tama�o del vector eAlquiler
 * \return Retorna 0 si no hubo problemas y 1 si no hay clientes
 *
 */
int mostrarClientesSinAlquiler(eCliente clientes[], int tamC, eAlquiler alquileres[], int tamAl, eLocalidad localidades[], int tamLoc)
{
    int flag;
    int flag2 = 0;

    if(!mostrarClientes(clientes, tamC, localidades, tamLoc))
    {
        system("cls");
        printf("***** Clientes que no alquilaron un juego *****\n\n");
        printf("No hay clientes en el sistema\n\n");
        return 1;
    }

    system("cls");
    printf("***** Clientes que no alquilaron un juego *****\n\n");
    for(int i=0; i < tamC; i++)
    {
        for(int j=0; j < tamAl; j++)
        {
            if(alquileres[j].idCliente == clientes[i].id)
            {
                flag = 1;
                break;
            }
        }
        if(!flag && clientes[i].isEmpty == 0)
        {
            mostrarCliente(clientes[i], localidades, tamLoc);
            flag2 = 1;
        }
        flag = 0;
    }
    if(flag2 == 0)
    {
        printf("No hay clientes sin alquiler\n");
    }
    printf("\n");
    return 0;
}


/** \brief Muestra los juegos que no fueron alquilados
 *
 * \param alquileres[] eAlquiler Vector de estructura eAlquiler
 * \param tamAl int Tama�o del vector eAlquiler
 * \param juegos[] eJuegos Vector de estruturas eJuegos
 * \param tamJ int Tama�o del vector eJuegos
 *
 */
void mostrarJuegosNoAlquilados(eAlquiler alquileres[], int tamAl, eJuego juegos[], int tamJ)
{
    int flag = 0;
    int flag2 = 0;
    system("cls");
    printf("***** Juegos que no fueron alquilados *****\n\n");

    for(int i=0; i < tamJ; i++)
    {
        for(int j=0; j < tamAl; j++)
        {
            if(juegos[i].id == alquileres[j].idJuego)
            {
                flag = 1;
                break;
            }
        }

        if(flag == 0)
        {
            if(i == 0)
            {
                printf(" Id     Descripcion   Importe  IdCategoria\n\n");
            }
            mostrarJuego(juegos[i]);
            flag2 = 1;
        }
        flag = 0;
    }
    if(!flag2)
    {
        printf("No hay juegos sin alquilar\n");
    }
    printf("\n");
}


void clientesDeLocalidad(eCliente clientes[],int tamC, eLocalidad localidades[],int tamLoc)
{
    int idLocalidad;
    mostrarLocalidades(localidades, tamLoc);
    printf("Ingrese el id de la localidad: ");
    scanf("%d", &idLocalidad);

    for(int i=0; i < tamC; i++)
    {
        if(clientes[i].idLocalidad == idLocalidad  && clientes[i].isEmpty == 0)
        {
            mostrarCliente(clientes[i], localidades, tamLoc);
        }
    }
}

void mostrarFechaYNombreDeAlquilerDeJuego(eAlquiler alquileres[], int tamAl, eCliente clientes[], int tamC, eJuego juegos[], int tamJ)
{
    int idJuego;
    char desc[51];
    mostrarJuegos(juegos, tamJ);
    printf("Ingrese id juego: ");
    scanf("%d", &idJuego);
    printf("\n");

    for(int i=0; i < tamAl; i++)
    {
        if(alquileres[i].idJuego == idJuego)
        {
            cargarCliente(alquileres[i].idCliente, clientes, tamC, desc);
            printf("%d/%d/%d   %s \n", alquileres[i].fecha.dia, alquileres[i].fecha.mes, alquileres[i].fecha.anio, desc);
        }
    }
    printf("\n");
}


void mostrarJuegosAlquiladosPorMujeres(eAlquiler alquileres[], int tamAl, eCliente clientes[], int tamC, eJuego juegos[], int tamJ)
{
    int flag = 0;

    for(int i=0; i < tamJ; i++)
    {
        for(int j=0; j < tamAl; j++)
        {
            for(int k=0; k < tamC; k++)
            {
                if((alquileres[j].idJuego == juegos[i].id) && (alquileres[j].idCliente == clientes[k].id) && (clientes[k].sexo == 'f'))
                {
                    flag = 1;
                }
            }
        }
        if(flag == 1)
        {
            mostrarJuego(juegos[i]);
        }
        flag = 0;
    }
}

void mostrarClientesDeUnJuego(eAlquiler alquileres[], int tamAl, eCliente clientes[], int tamC, eJuego juegos[], int tamJ, eLocalidad localidades[], int tamLoc)
{
    int idJuego;
    mostrarJuegos(juegos, tamJ);
    printf("Ingrese id de juego: ");
    scanf("%d", &idJuego);

    for(int i=0; i < tamAl; i++)
    {
        if(alquileres[i].idJuego == idJuego)
        {
            for(int j=0; j < tamC; j++)
            {
                if(alquileres[i].idCliente == clientes[j].id)
                {
                    mostrarCliente(clientes[j], localidades, tamLoc);
                }
            }
        }
    }
}


//void montoPorLocalidad()
