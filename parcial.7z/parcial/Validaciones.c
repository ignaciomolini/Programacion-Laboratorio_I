#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "Alquileres.h"


/** \brief Recibe un cadena de caracteres y verifica que solo sean numeros y no exceda de 21 caracteres
 *
 * \param vec[] char Cadena de caracteres
 * \return Retorna 0 si no es solo numerico y 1 si es solo numerico
 *
 */
int validarTelefono(char vec[])
{
    int i = 0;

    while(vec[i] != '\0')
    {
        if(vec[i] < '0' || vec[i] > '9')
        {
            return 0;
        }
        i++;
    }

    if(strlen(vec) > 21)
    {
        return 0;
    }

    return 1;
}


/** \brief Recibe un cadena de caracteres y verifica que solo sean letras o espacios y no exceda de 51 caracteres
 *
 * \param vec[] char Cadena de caracteres
 * \return Retorna 0 si no son solo letras y 1 si son solo letras
 *
 */
int validarNombre(char vec[])
{
    int i = 0;

    while(vec[i] != '\0')
    {
        if((vec[i] != ' ') && (vec[i] < 'a' || vec[i] > 'z') && (vec[i] < 'A' || vec[i] > 'Z'))
        {
            return 0;
        }
        i++;
    }

    if(strlen(vec) > 51)
    {
        return 0;
    }

    strlwr(vec);

    vec[0] = toupper(vec[0]);
    for(i=0; i < strlen(vec); i++)
    {
        if(vec[i] == ' ')
        {
            vec[i+1] = toupper(vec[i+1]);
        }
    }
    return 1;
}
