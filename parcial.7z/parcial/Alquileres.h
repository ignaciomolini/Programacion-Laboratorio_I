#include "Clientes.h"

#ifndef ALQUILERES_H_INCLUDED
#define ALQUILERES_H_INCLUDED

typedef struct
{
    int dia;
    int mes;
    int anio;

} eFecha;

typedef struct
{
    int id;
    int idJuego;
    int idCliente;
    eFecha fecha;
    int isEmpty;

}eAlquiler;

typedef struct
{
    int id;
    char descripcion[51];
    float importe;
    int idCategoria;

}eJuego;

typedef struct
{
    int id;
    char descripcion[51];

}eCategoria;

#endif // ALQUILERES_H_INCLUDED

void inicializarAlquileres(eAlquiler vec[], int tamAl);
int buscarAlquilerLibre(eAlquiler vec[], int tamAl);
int altaAlquiler(eAlquiler alquileres[], int tamAl, int idAlquiler, eCliente clientes[], int tamC, eJuego juegos[], int tamJ, eLocalidad localidades[], int tamLoc);
eAlquiler newAlquiler(int idAlquiler, int idCliente, int idJuego, eFecha fecha);
int cargarDescJuego(int idJuego, eJuego juegos[], int tamJ, char desc[]);
int buscarJuego(int id, eJuego vec[], int tamJ);
int cargarCliente(int idCliente, eCliente clientes[], int tamC, char nombre[]);
void mostrarAlquiler(eAlquiler al, eJuego juegos[], int tamJ, eCliente clientes[],int tamC);
void mostrarAlquileres(eAlquiler alquileres[], int tamAl,  eJuego juegos[], int tamJ, eCliente clientes[],int tamC);
void mostrarJuegos(eJuego juegos[], int tamJ);
void mostrarJuego(eJuego juego);
int hardcodearAlquileres(eAlquiler vec[], int tamAl, int cantidad);
