
int validarNombre(char vec[]);
int validarTelefono(char vec[]);
