#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "Clientes.h"

#define TAMC 20
#define TAMAL 20
#define TAMJ 5
#define TAMCAT 5

typedef struct
{
    int dia;
    int mes;
    int anio;

} eFecha;


typedef struct
{
    int id;
    char descripcion[51];
    int importe;
    int idCategoria;

}eJuego;

typedef struct
{
    int id;
    char descripcion[51];

}eCategoria;


typedef struct
{
    int id;
    int idJuego;
    int idCliente;
    eFecha fecha;

}eAlquiler;

int menu();

int main()
{
  //  int idAlquiler = 20000;
    int idCliente = 1000;
 //   eJuego juegos[TAMJ] = {{200, "Dados", 50, 5000}, {201, "Clue", 250, 5000}, {202, "Just Dance", 1000, 5003}, {203, "Equipo de magia", 500, 5004}};
 //   eCategoria categorias[TAMCAT] = {{5000, "mesa"}, {5001, "azar"}, {5002, "estrategia"}, {5003, "salon"}, {5004, "magia"}};
    eCliente clientes[TAMC];
    char salir = 'n';


    inicializarClientes(clientes, TAMC);
//    inicializarAlquileres(almuerzos, TAMAL);


    do
    {
        switch( menu())
        {
            case 1:
                if(altaCliente(clientes, TAMC, idCliente))
                {
                    idCliente++;
                }
                break;

            case 2:
                modificarCliente(clientes, TAMC);
                break;

            case 3:
                bajaCliente(clientes, TAMC);

            case 4:
                mostrarClientes(clientes, TAMC);


            case 5:
                printf("Confirma salir?:");
                fflush(stdin);
                salir = getche();
                printf("\n\n");
                break;

            default:
                printf("\nOpcion Invalida!\n\n");
        }
        system("pause");
    }
    while(salir == 'n');

    return 0;
}

int menu()
{
    int opcion;

    system("cls");
    printf("****** ABM Alumnos *******\n\n");
    printf("1-Alta alumno\n");
    printf("2-Modificar alumno\n");
    printf("3-Baja alumno\n");
    printf("4-Listar alumnos ordenados\n");
    printf("5-Salir\n\n");
    printf("Ingrese opcion: ");
    scanf("%d", &opcion);

    return opcion;
}

