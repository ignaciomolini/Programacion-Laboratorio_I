#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "Clientes.h"
#include "Alquileres.h"
#include "Informes.h"

#define TAMC 20
#define TAMAL 20
#define TAMJ 6
#define TAMCAT 5
#define TAMLOC 5

int menu();

int main()
{
    int idAlquiler = 20000;
    int idCliente = 1000;
    eJuego juegos[TAMJ] = {{200, "Dados", 50, 5001}, {201, "Clue", 250, 5000}, {202, "Just Dance", 1000, 5003},
                           {203, "Blake", 500, 5004}, {204, "Ruleta", 350, 5001}, {205, "Crisis", 300, 5002}};
    eCategoria categorias[TAMCAT] = {{5000, "mesa"}, {5001, "azar"}, {5002, "estrategia"}, {5003, "salon"}, {5004, "magia"}};
    eLocalidad localidades[TAMLOC] = {{300, "Lanus"}, {301, "Avellaneda"}, {302, "Temperley"}, {303, "Quilmes"}, {304, "Burzaco"}};
    eCliente clientes[TAMC];
    eAlquiler alquileres[TAMAL];
    char salir = 'n';

    inicializarClientes(clientes, TAMC);
    inicializarAlquileres(alquileres, TAMAL);
    idCliente = idCliente + hardcodearClientes(clientes, TAMC, 10);
    idAlquiler = idAlquiler + hardcodearAlquileres(alquileres, TAMAL, 10);

    do
    {
        switch( menu())
        {
            case 1:
                if(altaCliente(clientes, TAMC, idCliente, localidades, TAMLOC))
                {
                    idCliente++;
                }
                break;

            case 2:
                modificarCliente(clientes, TAMC, localidades, TAMLOC);
                break;

            case 3:
                bajaCliente(clientes, TAMC, localidades, TAMLOC);
                break;

            case 4:
                system("cls");
                mostrarClientes(clientes, TAMC, localidades, TAMLOC);
                break;

            case 5:
                if(altaAlquiler(alquileres, TAMAL, idAlquiler, clientes, TAMC, juegos, TAMJ, localidades, TAMLOC))
                {
                    idAlquiler++;
                }
                break;

            case 6:
                mostrarAlquileres(alquileres, TAMAL, juegos, TAMJ, clientes, TAMC);
                break;

            case 7:
                mostrarInformes(clientes, TAMC, alquileres, TAMAL, juegos, TAMJ, categorias, TAMCAT, localidades, TAMLOC);
                break;

            case 8:
                printf("\nConfirma salir?: ");
                fflush(stdin);
                salir = getche();
                while(salir != 's' && salir != 'n')
                {
                    printf("\nError. Ingrese s/n: ");
                    fflush(stdin);
                    salir = getche();
                }
                printf("\n\n");
                break;

            default:
                printf("\nOpcion Invalida!\n\n");
        }
        system("pause");
    }
    while(salir == 'n');

    return 0;
}

int menu()
{
    int opcion;

    system("cls");
    printf("****** ABM *******\n\n");
    printf("1-Alta cliente\n");
    printf("2-Modificar cliente\n");
    printf("3-Baja cliente\n");
    printf("4-Listar clientes ordenados\n");
    printf("5-Alta alquiler\n");
    printf("6-Listar alquileres\n");
    printf("7-Informes\n");
    printf("8-Salir\n\n");
    printf("Ingrese opcion: ");
    scanf("%d", &opcion);

    return opcion;
}



