#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Alquileres.h"
#include "Validaciones.h"


/** \brief  Carga en un vector de caracteres la descripcion del juego que se le pasa por id
 *
 * \param idJuego int Id del juego
 * \param juegos[] eJuego Vector de estrucuras de eJuego
 * \param tamJ int Tama�o del vector
 * \param desc[] char Vector donde se cargan los datos
 * \return Retorna 1 si realizo la carga y 0 si no se realizo
 *
 */
int cargarDescJuego(int idJuego, eJuego juegos[], int tamJ, char desc[])
{
    int todoOk = 0;

    for(int i=0; i < tamJ; i++)
    {
        if(idJuego == juegos[i].id)
        {
            strcpy(desc, juegos[i].descripcion);
            todoOk = 1;
            break;
        }
    }
    return todoOk;
}


/** \brief Busca si hay un juego con el id que se le paso
 *
 * \param id int Id del juego
 * \param juegos[] eJuego Vector de estrucuras de eJuego
 * \param tamJ int Tama�o del vector
 * \return Retorna el indice del vector que tiene el jeugo cn el id pasado, si no existe un juego con ese id retorna -1
 *
 */
int buscarJuego(int id, eJuego vec[], int tamJ)
{
    int indice = -1;

    for(int i=0; i < tamJ; i++)
    {
        if( vec[i].id == id)
        {
            indice = i;
            break;
        }
    }
    return indice;
}


/** \brief Carga el nombre y apellido del cliente que se pasa por id
 *
 * \param idCliente int Id del cliente
 * \param clientes[] eClientes Vector de estrucutas eCliente
 * \param tamC int Tama�o del vector
 * \param nombre[] char Vector donde se cargan los datos
 * \return Retorna 1 si se realizo la carga y 0 si no se realizo
 *
 */
int cargarCliente(int idCliente, eCliente clientes[], int tamC, char nombre[])
{
    int todoOk = 0;

    for(int i=0; i < tamC; i++)
    {
        if(idCliente == clientes[i].id)
        {
            strcpy(nombre, clientes[i].apellido);
            strcat(nombre, ", ");
            strcat(nombre, clientes[i].nombre);
            todoOk = 1;
            break;
        }
    }
    return todoOk;
}


/** \brief Muestra los datos del alquiler en la posicion que se le pasa
 *
 * \param al eAlquiler Estructura de eAlquiler
 * \param juegos[] eJuegos Vector de estruturas eJuegos
 * \param tamJ int Tama�o del vector eJuegos
 * \param clientes[] eClientes Vector de estruturas eCliente
 * \param tamC int Tama�o del vector eCliente
 *
 */
void mostrarAlquiler(eAlquiler al, eJuego juegos[], int tamJ, eCliente clientes[], int tamC)
{
    char descJuego[51];
    char nombreCliente[51];

    cargarDescJuego(al.idJuego, juegos, tamJ, descJuego);
    cargarCliente(al.idCliente, clientes, tamC, nombreCliente);
    printf(" %5d    %10s    %15s   %02d/%02d/%d\n",
           al.id,
           descJuego,
           nombreCliente,
           al.fecha.dia,
           al.fecha.mes,
           al.fecha.anio);
}


/** \brief Muestra los datos de todos lo alquileres cargados
 *
 * \param alquileres[] eAlquiler Vector de estructura eAlquiler
 * \param tamAl int Tama�o del vector eAlquiler
 * \param juegos[] eJuegos Vector de estruturas eJuegos
 * \param tamJ int Tama�o del vector eJuegos
 * \param clientes[] eClientes Vector de estruturas eCliente
 * \param tamC int Tama�o del vector eCliente
 *
 */
void mostrarAlquileres(eAlquiler alquileres[], int tamAl,  eJuego juegos[], int tamJ, eCliente clientes[],int tamC)
{
    int flag = 0;
    system("cls");

    printf("   Id          Juego           Cliente      Fecha \n\n");

    for(int i=0; i < tamAl; i++)
    {
        if( alquileres[i].isEmpty == 0)
        {
            mostrarAlquiler(alquileres[i], juegos, tamJ, clientes, tamC);
            flag = 1;
        }
    }

    if( flag == 0)
    {
        system("cls");
        printf("\nNo hay alquileres que mostrar\n");
    }

    printf("\n");
}


/** \brief Muestra los datos de los juegos cargados
 *
 * \param juegos[] eJuegos Vector de estruturas eJuegos
 * \param tamJ int Tama�o del vector eJuegos
 *
 */
void mostrarJuegos(eJuego juegos[], int tamJ)
{
    printf("\n Id    Descripcion    Importe  IdCategoria\n\n");
    for(int i=0; i < tamJ; i++)
    {
        mostrarJuego(juegos[i]);
    }
    printf("\n");
}


/** \brief Muestra los datos del juego en la posicion que se le pasa
 *
 * \param juego eJuego Estructura de eJuego
 *
 */
void mostrarJuego(eJuego juego)
{
    printf(" %3d  %10s  %10.2f      %3d\n", juego.id, juego.descripcion, juego.importe, juego.idCategoria);
}


/** \brief Carga en el valor isEmpty de todas las estrucutas de vector eAlquiler un 1 indicando
 *         que estan vacias
 * \param vec[] eAlquiler Vector de estructuras eAlquiler
 * \param tamAl int Tama�o del vector
 *
 */
void inicializarAlquileres(eAlquiler vec[], int tamAl)
{
    for(int i = 0; i < tamAl; i++)
    {
        vec[i].isEmpty = 1;
    }
}


/** \brief Busca si hay una estructura vacia dentro del vector
 *
 * \param vec[] eAlquiler Vector de estructuras eAlquiler
 * \param tamAl int Tama�o del vector
 * \return Retorna el indice del vector donde hay una estrutucra libre y si no hay ninguna libre retorna -1
 *
 */
int buscarAlquilerLibre(eAlquiler vec[], int tamAl)
{
    int indice = -1;

    for(int i=0; i < tamAl; i++)
    {
        if( vec[i].isEmpty == 1 )
        {
            indice = i;
            break;
        }
    }
    return indice;
}


/** \brief Se cargan los valores de la estructura eAlquiler
 *
 * \param alquileres[] eAlquiler Vector de estructuras eAlquiler
 * \param tamAl int Tama�o del vector eAlquiler
 * \param idAlquiler int Valor del id de alquiler
 * \param juegos[] eJuegos Vector de estruturas eJuegos
 * \param tamJ int Tama�o del vector eJuegos
 * \param clientes[] eClientes Vector de estruturas eCliente
 * \param tamC int Tama�o del vector eCliente
 * \return Retorna 1 si se realizo el alta y un 0 si no se realizo
 *
 */
int altaAlquiler(eAlquiler alquileres[], int tamAl, int idAlquiler, eCliente clientes[], int tamC, eJuego juegos[], int tamJ, eLocalidad localidades[], int tamLoc)
{
    int todoOk = 0;
    int indice;
    int idCliente;
    int idJuego;
    eFecha fecha;

    if(!mostrarClientes(clientes, tamC, localidades, tamLoc))
    {
        system("cls");
        printf("*****Alta Alquiler*****\n\n");
        printf("Primero debe dar de alta algun cliente\n\n");
        return todoOk;
    }

    system("cls");
    printf("*****Alta Alquiler*****\n\n");

    indice = buscarAlquilerLibre(alquileres, tamAl);

    if( indice == -1)
    {
        printf("\nSistema completo\n\n");
    }
    else
    {
        mostrarClientes(clientes, tamC, localidades, tamLoc);
        printf("Ingrese id cliente: ");
        scanf("%d", &idCliente);
        while(buscarCliente(idCliente, clientes, tamC) == -1)
        {
            printf("Error, no existe ese id. Ingrese id cliente: ");
            scanf("%d", &idCliente);
        }

        mostrarJuegos(juegos, tamJ);
        printf("Ingrese id juego: ");
        scanf("%d", &idJuego);
        while(buscarJuego(idJuego, juegos, tamJ) == -1)
        {
            printf("Error, no existe ese id. Ingrese id juego: ");
            scanf("%d", &idJuego);
        }

        printf("\nIngrese fecha : ");
        scanf("%d/%d/%d", &fecha.dia, &fecha.mes, &fecha.anio);

        alquileres[indice] = newAlquiler(idAlquiler, idCliente, idJuego, fecha);
        todoOk = 1;
        printf("\nAlta Alquiler exitosa!!\n\n");
    }
    return todoOk;
}


/** \brief Se le pasan los valores y se cargan en la estructura
 *
 * \param idAlquiler int Valor de id del alquiler
 * \param idCliente int Valor del id del cliente
 * \param idJuego int Valor del id del jeugo
 * \param fecha eFecha Valor de la fecha del alquiler
 * \return Retorna la estructura con los datos cargados
 *
 */
eAlquiler newAlquiler(int idAlquiler, int idCliente, int idJuego, eFecha fecha)
{
    eAlquiler al;
    al.id = idAlquiler;
    al.idCliente = idCliente;
    al.idJuego = idJuego;
    al.fecha = fecha;
    al.isEmpty = 0;

    return al;
}


/** \brief Se utiliza para probar el funcionamiento del programa, dandole
 *         los datos cargados de algunos alquileres
 * \param vec[] eAlquiler Vector de estructuras eAlquiler
 * \param tamAl int Tama�o del vector eAlquiler
 * \param cantidad int Cantidad de clientes que se van a utilizar
 * \return Retorna la cantidad de alquileres que se utilizaron
 *
 */
int hardcodearAlquileres(eAlquiler vec[], int tamAl, int cantidad)
{
    int contador = 0;

    eAlquiler suplentes[]=
    {
        { 20000, 201, 1000, {27, 12, 2019}, 0},
        { 20001, 202, 1002, {1, 3, 2019}, 0},
        { 20002, 204, 1002, {5, 6, 2019}, 0},
        { 20003, 202, 1004, {16, 11, 2019}, 0},
        { 20004, 200, 1001, {2, 1, 2019}, 0},
        { 20005, 205, 1000, {20, 11, 2019}, 0},
        { 20006, 201, 1002, {25, 8, 2019}, 0},
        { 20007, 204, 1008, {19, 9, 2019}, 0},
        { 20008, 201, 1007, {23, 3, 2019}, 0},
        { 20009, 203, 1001, {6, 1, 2019}, 0},

    };

    if( cantidad <= 10 && tamAl >= cantidad)
    {
        for(int i=0; i < cantidad; i++)
        {
            vec[i] = suplentes[i];
            contador++;
        }
    }

    return contador;
}
