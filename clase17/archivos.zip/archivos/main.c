#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    int id;
    char marca[30];
    int modelo;
    float precio;

}eAuto;

// MOSTRAR
int mostrarAuto(eAuto* unAuto);
int mostrarAutos(eAuto** autos, int tam);

// GETTERS Y SETTERS
int setIdAuto(eAuto* unAuto, int id);
int getIdAuto(eAuto* unAuto);
int setMarcaAuto(eAuto* unAuto, char* marca);
int getMarcaAuto(eAuto* unAuto, char* marca);
int setModeloAuto(eAuto* unAuto, int modelo);
int getModeloAuto(eAuto* unAuto);
int setPrecioAuto(eAuto* unAuto, float precio);
float getPrecioAuto(eAuto* unAuto);

// CONSTRUCTORES
eAuto* newAuto();
eAuto* newAutoParam(int id, char* marca, int modelo, float precio);

// COMPARISON

// ESCRITURA/LECTURA ARCHIVOS
int guardarAutosBinario(eAuto** lista, int tam, char* path);
int guardarAutosCsv(eAuto** lista, int tam, char* path);


int main()
{
    int tam = 0;
    int cant = 0;
    char buffer[4][30];
    FILE* f = NULL;
    eAuto* auxAuto = NULL;
    eAuto** auxLista = NULL;
    eAuto** lista = (eAuto**) malloc(sizeof(eAuto*));
    if(lista == NULL)
    {
        printf("No se pudo conseguir memoria\n");
        system("pause");
        exit(EXIT_FAILURE);
    }

    f = fopen("autos.csv", "r");
    if(f == NULL)
    {
        printf("No se pudo conseguir memoria\n");
        system("pause");
        exit(EXIT_FAILURE);
    }

    fscanf(f, "%[^,],%[^,],%[^,],%[^\n]\n", buffer[0], buffer[1], buffer[2], buffer[3]);

    while(!feof(f))
    {
        cant = fscanf(f, "%[^,],%[^,],%[^,],%[^\n]\n", buffer[0], buffer[1], buffer[2], buffer[3]);
        if(cant < 4)
        {
            break;
        }
        else
        {
            auxAuto = newAutoParam(atoi(buffer[0]), buffer[1], atoi(buffer[2]), atof(buffer[3]));
            if(auxAuto != NULL)
            {
                *(lista + tam) = auxAuto;
                tam++;
                auxLista = (eAuto**) realloc(lista, sizeof(eAuto*) * (tam + 1));
                if(auxLista != NULL)
                {
                    lista = auxLista;
                }
            }
        }
    }
    fclose(f);

    mostrarAutos(lista, tam);

    //--------- Guardo los autos en un archivo binario ---------

    if(guardarAutosBinario(lista, tam, "autos.bin"))
    {
        printf("Autos guardados en archivo binario\n");
    }
    else
    {
        printf("No se pudieron guardar los autos\n");
    }

    int tam2 = 0;
    eAuto** lista2 = (eAuto**) malloc(sizeof(eAuto*));
    if(lista2 == NULL)
    {
        printf("No se pudo conseguir memoria\n");
        system("pause");
        exit(EXIT_FAILURE);
    }

    f = fopen("autos.bin", "rb");
    if(f == NULL)
    {
        printf("No se pudo conseguir memoria\n");
        system("pause");
        exit(EXIT_FAILURE);
    }

    while(!feof(f))
    {
        auxAuto = newAuto();
        if(auxAuto == NULL)
        {
            break;
        }
        cant = fread(auxAuto, sizeof(eAuto), 1, f);
        if(cant < 1)
        {
            break;
        }
        else
        {
            if(auxAuto != NULL)
            {
                *(lista2 + tam2) = auxAuto;
                tam2++;
                auxLista = (eAuto**) realloc(lista2, sizeof(eAuto*) * (tam2 + 1));
                if(auxLista != NULL)
                {
                    lista2 = auxLista;
                }
            }
        }
    }
    fclose(f);

    mostrarAutos(lista2, tam2);

    if(guardarAutosBinario(lista, tam, "autos.bin"))
    {
        printf("Autos guardados en archivo de texto\n");
    }
    else
    {
        printf("No se pudieron guardar los autos\n");
    }


    return 0;
}

int setIdAuto(eAuto* unAuto, int id)
{
    int todoOk = 0;

    if(unAuto != NULL && id >= 1000 && id <=2000)
    {
        unAuto->id = id;
        todoOk = 1;
    }

    return todoOk;
}

int getIdAuto(eAuto* unAuto)
{
    int id = -1;

    if(unAuto != NULL)
    {
        id = unAuto->id;
    }

    return id;
}

int setMarcaAuto(eAuto* unAuto, char* marca)
{
    int todoOk = 0;

    if(unAuto != NULL && marca != NULL && strlen(marca) >= 3)
    {
        strcpy(unAuto->marca, marca);
        todoOk = 1;
    }

    return todoOk;
}

int getMarcaAuto(eAuto* unAuto, char* marca)
{
    int todoOk = 0;

    if(unAuto != NULL && marca != NULL)
    {
        strcpy(marca, unAuto->marca);
        todoOk = 1;
    }

    return todoOk;
}

int setModeloAuto(eAuto* unAuto, int modelo)
{
    int todoOk = 0;

    if(unAuto != NULL && modelo <= 2019 && modelo >= 1980)
    {
        unAuto->modelo = modelo;
        todoOk = 1;
    }

    return todoOk;
}

int getModeloAuto(eAuto* unAuto)
{
    int modelo = -1;

    if(unAuto != NULL)
    {
        modelo = unAuto->modelo;
    }

    return modelo;
}


int setPrecioAuto(eAuto* unAuto, float precio)
{
    int todoOk = 0;

    if(unAuto != NULL && precio <= 1500 && precio >= 500)
    {
        unAuto->precio = precio;
        todoOk = 1;
    }

    return todoOk;
}

float getPrecioAuto(eAuto* unAuto)
{
    float precio = -1;

    if(unAuto != NULL)
    {
        precio = unAuto->precio;
    }

    return precio;
}

eAuto* newAuto()
{
    eAuto* nuevo = (eAuto*) malloc(sizeof(eAuto));

    if(nuevo != NULL)
    {
        nuevo->id = 0;
        strcpy(nuevo->marca, " ");
        nuevo->modelo = 0;
        nuevo->precio = 0;
    }

    return nuevo;
}

eAuto* newAutoParam(int id, char* marca, int modelo, float precio)
{
    eAuto* nuevo = newAuto();

    if(nuevo != NULL)
    {
        if((setIdAuto(nuevo, id) &&
            setMarcaAuto(nuevo, marca) &&
            setModeloAuto(nuevo, modelo) &&
            setPrecioAuto(nuevo, precio)) == 0)
            {
                free(nuevo);
                nuevo = NULL;
            }
    }

    return nuevo;
}

int mostrarAuto(eAuto* unAuto)
{
    int todoOk = 0;

    if(unAuto != NULL)
    {
        printf(" %d  %15s  %d  %6.2f \n", unAuto->id, unAuto->marca, unAuto->modelo, unAuto->precio);
        todoOk = 1;
    }

    return todoOk;
}

int mostrarAutos(eAuto** autos, int tam)
{
    int todoOk = 0;

    if(autos != NULL && tam > 0)
    {
        for(int i=0; i < tam; i++)
        {
            mostrarAuto(*(autos + i));
        }
        todoOk = 1;
    }
    return todoOk;
}

int guardarAutosBinario(eAuto** lista, int tam, char* path)
{
    int todoOk = 0;
    FILE* f = NULL;

    if(lista != NULL && tam > 0 && path != NULL)
    {
        f = fopen(path, "wb");
        if(f == NULL)
        {
            printf("No se pudo conseguir memoria\n");
            system("pause");
            return todoOk;
        }

        for(int i=0; i < tam; i++)
        {
            fwrite(*(lista + i), sizeof(eAuto), 1, f);
        }

        fclose(f);
        todoOk = 1;
    }

    return todoOk;
}

int guardarAutosCsv(eAuto** lista, int tam, char* path)
{
    int todoOk = 0;
    FILE* f = NULL;

    if(lista != NULL && tam > 0 && path != NULL)
    {
        f = fopen(path, "w");
        if(f == NULL)
        {
            printf("No se pudo conseguir memoria\n");
            system("pause");
            return todoOk;
        }

        fprintf(f, "id, marca, modelo, precio\n");

        for(int i=0; i < tam; i++)
        {
            fprintf(f, "%d,%s,%d,%.2f\n", (*(lista + i))->id, (*(lista + i))->marca, (*(lista + i))->modelo, (*(lista + i))->precio);
        }

        fclose(f);
        todoOk = 1;
    }

    return todoOk;
}
