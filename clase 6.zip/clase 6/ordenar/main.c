#include <stdio.h>
#include <stdlib.h>

void ordenarVectorInt(int vec[], int tam, int criterio);

int main()
{
    int vec[] = {7, 4, 5, 9, 2};


    printf("Muestro el vector ordenado\n\n");
    ordenarVectorInt(vec, 5, 0);

    return 0;
}

void ordenarVectorInt(int vec[], int tam, int criterio)
{
    int aux;

    for(int i = 0; i < tam-1; i++)
    {
        for(int j = i+1; j < tam; j++)
        {
            if(vec[i] > vec[j] && criterio)
            {
                aux = vec[i];
                vec[i] = vec[j];
                vec[j] = aux;
            }
            else if(vec[i] < vec[j] && !criterio)
            {
                aux = vec[i];
                vec[i] = vec[j];
                vec[j] = aux;
            }
        }
    }

    for(int i=0; i<tam; i++)
    {
        printf("%d ", vec[i]);

    }

    printf("\n");

}
