#include <stdio.h>
#include <stdlib.h>
#define TAM 1

void mostrarAlumnos(int leg[], int age[], char sex[], int n1[], int n2[], float prom[], int tam);
void mostrarAlumno(int legajo, int edad, char sexo, int nota1, int nota2, float promedio);

int main()
{
    int legajos[TAM];
    int edades[TAM];
    char sexos[TAM];
    int notasP1[TAM];
    int notasP2[TAM];
    float promedios[TAM];

    for(int i = 0; i < TAM; i++)
    {
        printf("Ingrese legajo: ");
        scanf("%d", &legajos[i]);

        printf("Ingrese edad: ");
        scanf("%d", &edades[i]);

        printf("Ingrese sexo: ");
        fflush(stdin);
        scanf("%c", &sexos[i]);

        printf("Ingrese nota parcial 1: ");
        scanf("%d", &notasP1[i]);

        printf("Ingrese nota parcial 2: ");
        scanf("%d", &notasP2[i]);

        promedios[i] = (float) (notasP1[i] + notasP2[i]) / 2;
    }

    printf("Legajos  edades  sexos  notasP1  notasP2  promedio");

  /*  for(int i = 0; i < TAM; i++)
    {
        printf("\n   %d      %d      %c     %d       %d        %.2f", legajos[i], edades[i], sexos[i], notasP1[i], notasP2[i], promedios[i]);
    }*/
    mostrarAlumno(legajos[0], edades[0], sexos[0], notasP1[0], notasP2[0

    mostrarAlumnos(legajos, edades, sexos, notasP1, notasP2, promedios, TAM);

    return 0;
}

void mostrarAlumnos(int legs[], int ages[], char sexs[], int n1[], int n2[], float proms[], int tam)
{
    for(int i = 0; i < tam; i++)
    {
        printf("\n   %d      %d      %c     %d       %d        %.2f", legs[i], ages[i], sexs[i], n1[i], n2[i], proms[i]);
    }
}

void mostrarAlumno(int legajo, int edad, char sexo, int nota1, int nota2, float promedio)
{
    printf("\n   %d      %d      %c     %d       %d        %.2f", legajo, edad, sexo, nota1, nota2, promedio);
}
