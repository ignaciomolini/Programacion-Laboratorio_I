#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "computer.h"
#include "LinkedList.h"

/** \brief Busca espacio en memoria para una estructura de e inicializa los valores de la misma
 *
 * \return eComputer* Retorna un puntero a eComputer
 *
 */
eComputer* computer_new()
{
    eComputer* nuevo = (eComputer*) malloc(sizeof(eComputer));

    if(nuevo != NULL)
    {
        nuevo->id = 0;
        strcpy(nuevo->descripcion, " ");
        nuevo->precio = 0;
        nuevo->idTipo = 0;
        strcpy(nuevo->oferta, " ");
    }

    return nuevo;
}

/** \brief Carga los valores que se le pasan por parametro a una nueva estructura de cachorro
 *
 * \param idSt char* Direccion de memoria del id
 * \param dominioStr char* Direccion de memoria del domino
 * \param anioStr char* Direccion de memoria del anio
 * \param tipoStr char* Direccion de memoria del tipo
 * \return eComputer* Retorna un puntero a eComputer
 *
 */
eComputer* computer_newParametros(int id, char* descripcion, float precio, int idTipo)
{
    eComputer* nuevo = computer_new();

    if(nuevo != NULL)
    {
        if(!computer_setId(nuevo, id) || !computer_setDescripcion(nuevo, descripcion) ||
           !computer_setPrecio(nuevo, precio) || !computer_setIdTipo(nuevo, idTipo))
        {
            free(nuevo);
            nuevo = NULL;
        }
    }

    return nuevo;
}


/** \brief Carga en la estructura  de cachorros el id que se le pasa por parametro
 *
 * \param this eComputer* Direccion de memoria de la estructura
 * \param id int Valor del id
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int computer_setId(eComputer* this, int id)
{
    int todoOk = 0;

    if(this != NULL)
    {
        this->id = id;
        todoOk = 1;
    }

    return todoOk;
}

/** \brief Carga en el lugar donde apunta la direccion de memoria que se le pasa el valor de la estructura
 *
 * \param this eComputer* Direccion de memoria de la estructura
 * \param id int* Direccion de memoria del id
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int computer_getId(eComputer* this, int* id)
{
    int todoOk = 0;

    if(this != NULL && id != NULL)
    {
        *id = this->id;
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en la estructura  de dominio el dominio que se le pasa por parametro
 *
 * \param this eComputer* Direccion de memoria de la estructura
 * \param dominio char* Direccion de memoria de la dominio
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int computer_setDescripcion(eComputer* this, char* descripcion)
{
    int todoOk = 0;

    if(this != NULL && descripcion != NULL)
    {
        strcpy(this->descripcion, descripcion);
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en el lugar donde apunta la direccion de memoria que se le pasa el valor de la estructura
 *
 * \param this eComputer* Direccion de memoria de la estructura
 * \param dominio char* Direccion de memoria de la dominio
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int computer_getDescripcion(eComputer* this, char* descripcion)
{
    int todoOk = 0;

    if(this != NULL && descripcion != NULL)
    {
        strcpy(descripcion, this->descripcion);
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en la estructura  de dominio el anio que se le pasa por parametro
 *
 * \param this eComputer* Direccion de memoria de la estructura
 * \param anio int Nombre del anio
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int computer_setPrecio(eComputer* this, float precio)
{
    int todoOk = 0;

    if(this != NULL && precio >= 0)
    {
        this->precio = precio;
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en el lugar donde apunta la direccion de memoria que se le pasa el valor de la estructura
 *
 * \param this eComputer* Direccion de memoria de la estructura
 * \param anio int* Direccion de memoria del anio
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int computer_getPrecio(eComputer* this, float* precio)
{
    int todoOk = 0;

    if(this != NULL && precio != NULL)
    {
        *precio = this->precio;
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Carga en la estructura  de dominio el tipo que se le pasa por parametro
 *
 * \param this eComputer* Direccion de memoria de la estructura
 * \param tipo char Valor del tipo
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int computer_setIdTipo(eComputer* this, int idTipo)
{
    int todoOk = 0;

    if(this != NULL)
    {
        this->idTipo = idTipo;
        todoOk = 1;
    }

    return todoOk;
}

/** \brief Carga en el lugar donde apunta la direccion de memoria que se le pasa el valor de la estructura
 *
 * \param this eComputer* Direccion de memoria de la estructura
 * \param tipo char* Direccion de memoria del tipo
 * \return int Retorna 1 si se cargo el valor y 0 si no
 *
 */
int computer_getIdTipo(eComputer* this, int* idTipo)
{
    int todoOk = 0;

    if(this != NULL && idTipo != NULL)
    {
        *idTipo = this->idTipo;
        todoOk = 1;
    }

    return todoOk;
}



int computer_setOferta(eComputer* this, char* oferta)
{
    int todoOk = 0;

    if(this != NULL && oferta != NULL)
    {
        strcpy(this->oferta, oferta);
        todoOk = 1;
    }

    return todoOk;
}


int computer_getOferta(eComputer* this, char* oferta)
{
    int todoOk = 0;

    if(this != NULL && oferta != NULL)
    {
        strcpy(oferta, this->oferta);
        todoOk = 1;
    }

    return todoOk;
}


/** \brief Muestra el dominio pasado por parametro
 *
 * \param this eComputer* Puntero a la estructura eComputer
 *
 */
void mostrarComputer(eComputer* this)
{
    int id;
    char descripcion[128];
    float precio;
    int idTipo;
    char tipo[51];
    char oferta[51];


    computer_getId(this, &id);
    computer_getDescripcion(this, descripcion);
    computer_getPrecio(this, &precio);
    computer_getIdTipo(this, &idTipo);
    computer_getOferta(this, oferta);

    if(idTipo == 1)
    {
        strcpy(tipo, "DESKTOP");
    }
    else
    {
        strcpy(tipo, "LAPTOP");
    }


    printf("| %4d |   %105s  |  %10.2f  |   %10s  |  %20s  |\n", id, descripcion, precio, tipo, oferta);
}


/** \brief Muestra todos elementos de la lista
 *
 * \param this LinkedList* Puntero al LinkedList
 * \return int Retorna la cantidad de elementos mostrados
 *
 */
int mostrarComputers(LinkedList* this)
{
    int cantidad = 0;
    int tam;

    if(this != NULL)
    {
        tam = ll_len(this);

        printf("\n|  Id  |                                           Descripcion                                                 |       Precio       |       Tipo      |     Oferta    |\n");
        printf("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");

        for(int i=0; i<tam; i++)
        {
            if(i>0)
            {
                mostrarComputer((eComputer*) ll_get(this, i));
                cantidad++;
            }
        }
    }

    return cantidad;
}


int sortCompuByIdTipo(void* compu1, void* compu2)
{
    int orden;
    int idTipo1;
    int idTipo2;
    eComputer* auxCompu1 = NULL;
    eComputer* auxCompu2 = NULL;

    if(compu1 != NULL && compu2 != NULL)
    {
        auxCompu1 = (eComputer*) compu1;
        auxCompu2 = (eComputer*) compu2;
        computer_getIdTipo(auxCompu1, &idTipo1);
        computer_getIdTipo(auxCompu2, &idTipo2);

        if(idTipo1 > idTipo2)
        {
            orden = 1;
        }
        else if(idTipo1 < idTipo2)
        {
            orden = -1;
        }
        else
        {
            orden = 0;
        }
    }
    return orden;
}


void* asignarOferta(void* pComputer)
{
    eComputer* auxComputer = NULL;
    int idTipo;
    float precio;

    if(pComputer != NULL)
    {
        auxComputer = (eComputer*) pComputer;
        computer_getIdTipo(auxComputer, &idTipo);
        computer_getPrecio(auxComputer, &precio);
        if(idTipo == 2)
        {
            computer_setOferta(auxComputer, "SIN DATOS");
        }
        else if(idTipo == 1 && precio > 20000)
        {
            computer_setOferta(auxComputer, "50% DE DESCUENTO");
        }
    }

    return auxComputer;
}


 int filtroLaptop(void* pElement, int tipo)
{
    int ret = -1;
    int idTipo;

    if(pElement != NULL)
    {
        computer_getIdTipo((eComputer*) pElement, &idTipo);

        if(idTipo == tipo)
        {
            ret = 0;
        }
        else
        {
            ret = 1;
        }
    }

    return ret;
}




