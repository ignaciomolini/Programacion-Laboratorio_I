#include "LinkedList.h"

#ifndef COMPUTER_H_INCLUDED
#define COMPUTER_H_INCLUDED


typedef struct
{
    int id;
    char descripcion[128];
    float precio;
    int idTipo;
    char oferta[51];
}eComputer;

#endif // COMPUTER_H_INCLUDED

eComputer* computer_new();
eComputer* computer_newParametros(int id, char* descripcion, float precio, int idTipo);

int computer_setId(eComputer* this, int id);
int computer_getId(eComputer* this, int* id);
int computer_setDescripcion(eComputer* this, char* descripcion);
int computer_getDescripcion(eComputer* this, char* descripcion);
int computer_setPrecio(eComputer* this, float precio);
int computer_getPrecio(eComputer* this, float* precio);
int computer_setIdTipo(eComputer* this, int idTipo);
int computer_getIdTipo(eComputer* this, int* idTipo);
int computer_setOferta(eComputer* this, char* oferta);
int computer_getOferta(eComputer* this, char* oferta);

void mostrarComputer(eComputer* this);
int mostrarComputers(LinkedList* this);
int sortCompuByIdTipo(void* compu1, void* compu2);
void* asignarOferta(void* pComputer);
int filtroLaptop(void* pElement, int tipo);

