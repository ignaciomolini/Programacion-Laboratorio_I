int parser_CompuFromText(FILE* pFile , LinkedList* pArrayListCar);

