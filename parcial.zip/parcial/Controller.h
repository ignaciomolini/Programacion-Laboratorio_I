int controller_loadFromText(char* path , LinkedList* pArrayListCar);
int controller_ListComputer(LinkedList* pArrayListComputer);
int controller_sortComputer(LinkedList* pArrayListCompu);
int controller_saveAsText(char* path , LinkedList* pArrayListCar);


