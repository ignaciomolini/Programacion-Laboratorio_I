#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "LinkedList.h"
#include "Controller.h"
#include "computer.h"
#include "parser.h"
#include "validaciones.h"


/** \brief Carga los datos de los autos desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListCompu LinkedList*
 * \return int Retorna la cantidad de autos cargados
 *
 */
int controller_loadFromText(char* path , LinkedList* pArrayListCompu)
{
    int contador = 0;
    FILE* file = NULL;

    if(pArrayListCompu != NULL && path != NULL)
    {
        file = fopen(path, "r");

        if(file != NULL)
        {
            contador = parser_CompuFromText(file, pArrayListCompu);
        }
    }

    fclose(file);

    return contador;
}


/** \brief Listar autos
 *
 * \param path char*
 * \param pArrayListCompu LinkedList*
 * \return int Retorna la cantidad de autos en la lista
 *
 */
int controller_ListComputer(LinkedList* pArrayListCompu)
{
    int contador = 0;
    if(pArrayListCompu != NULL)
    {
        if(ll_isEmpty(pArrayListCompu))
        {
            printf("\nNo hay autos por mostrar.\n\n");
            return contador;
        }
        contador = mostrarComputers(pArrayListCompu);
    }
    return contador;
}

/** \brief Ordenar autos
 *
 * \param path char*
 * \param pArrayListCompu LinkedList*
 * \return int
 *
 */
int controller_sortComputer(LinkedList* pArrayListCompu)
{
    int todoOk = 0;

    ll_sort(pArrayListCompu, sortCompuByIdTipo, 1);

    return todoOk;
}


/** \brief Guarda los datos de los autos en el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListCompu LinkedList*
 * \return int Retorna 1 si se guardaron los datos
 *
 */
int controller_saveAsText(char* path , LinkedList* pArrayListCompu)
{
    int todoOk = 0;
    int i;
    int largoArray = 0;
    int id;
    char descripcion[51];
    float precio;
    int idTipo;
    char oferta[51];

    FILE* file = NULL;
    eComputer* auxCompu = NULL;

    if(pArrayListCompu != NULL && path != NULL)
    {
        largoArray = ll_len(pArrayListCompu);

        file = fopen(path, "w");
        if(file == NULL)
        {
            return todoOk;
        }
        if(largoArray > 0)
        {
            fprintf(file, "id,descripcion,precio,idTipo,oferta\n");
            for(i=0; i < largoArray; i++)
            {
                auxCompu = (eComputer*) ll_get(pArrayListCompu, i);
                if(auxCompu != NULL)
                {
                    computer_getId(auxCompu, &id);
                    computer_getDescripcion(auxCompu, descripcion);
                    computer_getPrecio(auxCompu, &precio);
                    computer_getIdTipo(auxCompu, &idTipo);
                    computer_getOferta(auxCompu, oferta);
                    fprintf(file, "%d,%s,%f,%d\n", id, descripcion, precio, idTipo);
                }
                else
                {
                    break;
                }
            }
            if(i == largoArray)
            {
                todoOk = 1;
            }
        }
        fclose(file);
    }
    return todoOk;
}
