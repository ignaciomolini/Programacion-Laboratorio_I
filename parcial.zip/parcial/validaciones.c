#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "validaciones.h"

/**
 * \brief Verifica si el valor recibido es num�rico
 * \param str Array con la cadena a ser analizada
 * \return 1 si es n�merico y 0 si no lo es
 *
 */
int esNumerico(char str[])
{
   int i = 0;

   while(str[i] != '\0')
   {
       if(str[i] < '0' || str[i] > '9')
       {
           return 0;
       }
       i++;
   }
   return 1;
}


/**
 * \brief Verifica si el valor recibido es num�rico aceptando flotantes
 * \param str Array con la cadena a ser analizada
 * \return 1 si es n�merico y 0 si no lo es
 *
 */
int esNumericoFlotante(char str[])
{
   int i = 0;
   int cantidadPuntos = 0;

   while(str[i] != '\0')
   {
       if (str[i] == '.' && cantidadPuntos == 0)
       {
           cantidadPuntos++;
           i++;
           continue;
       }
       if(str[i] < '0' || str[i] > '9')
       {
           return 0;
       }
       i++;
   }
   return 1;
}

/**
 * \brief Verifica si el valor recibido contiene solo letras
 * \param str Array con la cadena a ser analizada
 * \return 1 si contiene solo ' ' y letras y 0 si no lo es
 *
 */
int esSoloLetras(char str[])
{
   int i=0;

   while(str[i] != '\0')
   {
       if((str[i] != ' ') && (str[i] < 'a' || str[i] > 'z') && (str[i] < 'A' || str[i] > 'Z'))
       {
           return 0;
       }
       i++;
   }
   return 1;
}


/**
 * \brief Verifica si el valor recibido contiene solo letras y guiones
 * \param str Array con la cadena a ser analizada
 * \return 1 si contiene solo ' ', letras y guiones, y 0 si no lo es
 *
 */
int esSoloLetrasYGuiones(char str[])
{
   int i=0;
   while(str[i] != '\0')
   {
       if((str[i] != ' ') && (str[i] < 'a' || str[i] > 'z') && (str[i] < 'A' || str[i] > 'Z') && str[i] != '-')
           return 0;
       i++;
   }
   return 1;
}

/**
 * \brief Verifica si el valor recibido contiene solo letras y n�meros
 * \param str Array con la cadena a ser analizada
 * \return 1 si contiene solo espacio o letras y n�meros, y 0 si no lo es
 *
 */
int esAlfaNumerico(char str[])
{
   int i=0;
   while(str[i] != '\0')
   {
       if((str[i] != ' ') && (str[i] < 'a' || str[i] > 'z') && (str[i] < 'A' || str[i] > 'Z') && (str[i] < '0' || str[i] > '9'))
           return 0;
       i++;
   }
   return 1;
}


/**
 * \brief Verifica si el valor recibido contiene solo letras, n�meros y guiones
 * \param str Array con la cadena a ser analizada
 * \return 1 si contiene solo espacio o letras, n�meros y guiones, y 0 si no lo es
 *
 */
int esAlfaNumericoYGuiones(char str[])
{
   int i=0;
   while(str[i] != '\0')
   {
       if((str[i] != ' ') && (str[i] < 'a' || str[i] > 'z') && (str[i] < 'A' || str[i] > 'Z') && (str[i] < '0' || str[i] > '9') && str[i] != '-')
           return 0;
       i++;
   }
   return 1;
}

/** \brief Valida y carga la cadena en la variable pasada por parametro
 *
 * \param vec[] char Cadena de caracteres
 * \param mensaje[] char Mensaje con indicacion
 * \param mensajeError[] char Mensaje de error
 * \param maxLen int Tama�o maximo de caracteres
 * \param minLen int Tama�o minimo de caracteres
 * \param intentos int Cantidad de intentos
 * \return Retorna 0 si no hay mas intentos y 1 si se cargo la cadena en la variable
 *
 */
int obtenerString(char vec[], char mensaje[], char mensajeError[], int maxLen, int minLen, int intentos)
{
    int flag = 1;
    char string[128];

    printf("%s", mensaje);
    fflush(stdin);
    gets(string);

    do
    {
        if(!flag)
        {
            printf("%s", mensajeError);
            fflush(stdin);
            gets(string);
            flag = 1;
        }

        if(strlen(string) < minLen || strlen(string) > maxLen)
        {
            flag = 0;
        }

        if(flag)
        {
            strcpy(vec, string);
        }
        intentos--;
    }while(!flag && intentos > 0);

    return flag;
}

/** \brief Valida y carga el nombre en la variable pasada por parametro
 *
 * \param vec[] char Cadena de caracteres
 * \param mensaje[] char Mensaje con indicacion
 * \param mensajeError[] char Mensaje de error
 * \param intentos int Cantidad de intentos
 * \return Retorna 0 si no son solo letras y 1 si son solo letras
 *
 */
int obtenerNombre(char vec[], char mensaje[], char mensajeError[], int intentos)
{
    int flag = 1;
    char nombre[51];

    printf("%s", mensaje);
    fflush(stdin);
    gets(nombre);
    primeraLetraMayus(nombre);

    do
    {
        if(!flag)
        {
            printf("%s", mensajeError);
            fflush(stdin);
            gets(nombre);
            primeraLetraMayus(nombre);
            flag = 1;
        }

        if(!esSoloLetras(nombre) || strlen(nombre) < 2 || strlen(nombre) > 50)
        {
            flag = 0;
        }

        if(flag)
        {
            strcpy(vec, nombre);
        }
        intentos--;
    }while(!flag && intentos > 0);

    return flag;
}

/**
 * \brief Pasa toda la cadena a minusculas y luego las primeras letras a mayusculas
 * \param str Array con la cadena a ser analizada
 *
 */
void primeraLetraMayus(char str[])
{
    int i = 0;

    strlwr(str);
    str[0] = toupper(str[0]);
    while(str[i] != '\0')
    {
        if(str[i] == ' ' || str[i] == '-')
        {
            str[i+1] = toupper(str[i+1]);
        }
        i++;
    }
}


/** \brief Carga y valida un entero en la variable pasada por parametro
 *
 * \param var int* Puntero a entero
 * \param mensaje[] char Mensaje con indicacion
 * \param mensajeError[] char Mensaje de error
 * \param max int Maximo entero que se puede ingresar
 * \param min int Minimo entero que se puede ingresar
 * \param intentos int Cantidad de intentos
 * \return int Retorna 1 si se cargo el valor en la variable y 0 si no lo hizo
 *
 */
int obtenerEntero(int* var, char mensaje[], char mensajeError[], int max, int min, int intentos)
{
    int flag = 1;
    char numero[20];

    printf("%s", mensaje);
    fflush(stdin);
    gets(numero);

    do
    {
        if(!flag)
        {
            printf("%s", mensajeError);
            fflush(stdin);
            gets(numero);
            flag = 1;
        }
        if(!esNumerico(numero) || atoi(numero) > max || atoi(numero) < min)
        {
            flag = 0;
        }

        if(flag)
        {
            *var = atoi(numero);
        }
        intentos--;
    }while(!flag && intentos > 0);

    return flag;
}

/** \brief Carga y valida un flotante en la variable pasada por parametro
 *
 * \param var float* Puntero a flotante
 * \param mensaje[] char Mensaje con indicacion
 * \param mensajeError[] char Mensaje de error
 * \param max int Maximo flotante que se puede ingresar
 * \param min int Minimo flotante que se puede ingresar
 * \param intentos int Cantidad de intentos
 * \return int Retorna 1 si se cargo el valor en la variable y 0 si no lo hizo
 *
 */
int obtenerFlotante(float* var, char mensaje[], char mensajeError[], float max, float min, int intentos)
{
    int flag = 1;
    char numero[20];

    printf("%s", mensaje);
    fflush(stdin);
    gets(numero);

    do
    {
        if(!flag)
        {
            printf("%s", mensajeError);
            fflush(stdin);
            gets(numero);
            flag = 1;
        }
        if(!esNumericoFlotante(numero) || atof(numero) > max || atof(numero) < min)
        {
            flag = 0;
        }

        if(flag)
        {
            *var = atof(numero);
        }
        intentos--;
    }while(!flag && intentos > 0);

    return flag;
}


/** \brief
 *
 * \param vec[] char Cadena de caracteres
 * \return Retorna 0 si no es solo numerico y 1 si es solo numerico
 *
 */
int obtenerTelefono(char telefono[], char mensaje[], char mensajeError[], int intentos)
{
    int flag = 1;
    int i = 0;
    char vec[10];

    printf("%s", mensaje);
    fflush(stdin);
    gets(vec);

    do
    {
        if(!flag)
        {
            printf("%s", mensajeError);
            fflush(stdin);
            gets(vec);
            flag = 1;
        }

        if(strlen(vec) > 9 || strlen(vec) < 8)
        {
            flag = 0;
        }
        else
        {
            while(vec[i] != '\0')
            {
                if((vec[i] < '0' || vec[i] > '9') && vec[i] != '-')
                {
                    flag = 0;
                    break;
                }
                i++;
            }
            if(vec[4] != '-')
            {
                flag = 0;
            }
            if(flag)
            {
                strcpy(telefono, vec);
            }
        }
        intentos--;
    }while(!flag && intentos > 0);

    return flag;
}



/** \brief Valida que la fecha pasada por parametro sea correcta
 *
 * \param dia int Valor del dia
 * \param mes int Valor del mes
 * \param anio int Valor del anio
 * \return int Retorna 1 si es correcta y 0 si no lo es
 *
 */
int esFechaValida(int dia, int mes, int anio)
{
    int todoOk = 0;

    if(anio >= 1900 && anio <=2100 && mes > 0 && mes <= 12)
    {
        switch ( mes )
        {
            case  1 :
            case  3 :
            case  5 :
            case  7 :
            case  8 :
            case 10 :
            case 12 :
                if ( dia >= 1 && dia <= 31 )
                {
                     todoOk = 1;
                }
                break;

            case  4 :
            case  6 :
            case  9 :
            case 11 :
                if ( dia >= 1 && dia <= 30 )
                {
                    todoOk = 1;
                }
                break;

            case  2 :
                if(anio % 4 == 0 && dia >= 1 && dia <= 29 )
                {
                    todoOk = 1;
                }
                else if( dia >= 1 && dia <= 28 )
                {
                    todoOk = 1;
                }
        }
    }

    return todoOk;
}


/** \brief Carga y valida una fecha en la estructura que se le pasa por parametro
 *
 * \param fecha eFecha* Puntero a la estructura fecha
 * \param mensaje[] char Mensaje de indicacion
 * \param mensajeError[] char Mensaje de error
 * \return int Retorna 1 si se cargaron los datos y 0 si no
 *
 */
/*int obtenerFecha(eFecha* fecha, char mensaje[], char mensajeError[])
{
    int todoOk = 0;
    int auxDia;
    int auxMes;
    int auxAnio;

    printf("%s", mensaje);

    while(scanf("%d/%d/%d", &auxDia, &auxMes, &auxAnio) != 3 || !esFechaValida(auxDia, auxMes, auxAnio))
    {
        printf("%s", mensajeError);
        fflush(stdin);
    }

    if(esFechaValida(auxDia, auxMes, auxAnio))
    {
        fecha->dia = auxDia;
        fecha->mes = auxMes;
        fecha->anio = auxAnio;

        todoOk = 1;
    }

    return todoOk;
}
*/


