#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "LinkedList.h"
#include "computer.h"
#include "menu.h"
#include "Controller.h"

int main()
{
    char salir = 'n';
    int cantidadCompu = 0;
    char nombreArchivo[20];
    LinkedList* listaCompu = ll_newLinkedList();
    LinkedList* listaDesktop = ll_newLinkedList();

     do{
        switch(menu())
        {
            case 1:
                if(ll_isEmpty(listaCompu))
                {
                    printf("Ingrese el nombre del archivo: ");
                    fflush(stdin);
                    gets(nombreArchivo);
                    while(strcmp(nombreArchivo, "datos_Fin.csv") != 0)
                    {
                        printf("Error. Ingrese el nombre del archivo: ");
                        fflush(stdin);
                        gets(nombreArchivo);
                    }

                    cantidadCompu = controller_loadFromText(nombreArchivo, listaCompu);
                    if(cantidadCompu > 0)
                    {
                        printf("\nSe cargaron en el sistema las computadoras.\n\n");
                    }
                    else
                    {
                        printf("\nNo se pudo cargar ninguna computadora.\n\n");
                    }
                }
                else
                {
                    printf("\nYa se cargaron las computadoras anteriormente.\n\n");
                }
                break;

            case 2:
                if(!controller_sortComputer(listaCompu))
                {
                    printf("\nSe ordenaron los datos.\n\n");
                }
                break;

            case 3:
                controller_ListComputer(listaCompu);
                break;

            case 4:
                if(!ll_isEmpty(listaCompu))
                {
                    listaCompu = ll_map(listaCompu, asignarOferta);
                    printf("\nCampo oferta asignado\n\n");
                }
                else
                {
                    printf("\nNo hay computadoras en el sistema.\n\n");
                }
                break;

            case 5:
                if(!ll_isEmpty(listaCompu))
                {
                    listaDesktop = ll_filter(listaCompu, filtroLaptop, 2);
                    mostrarComputers(listaDesktop);
                }
                else
                {
                    printf("\nNo hay computadoras en el sistema.\n\n");
                }

                break;


            case 6:
                if(!ll_isEmpty(listaCompu) && !ll_isEmpty(listaDesktop))
                {
                   if(controller_saveAsText("filtrado.csv", listaDesktop))
                   {
                       printf("\nSe guardaron los datos correctamente\n");
                   }
                }
                else
                {
                    printf("\nNo hay computadoras en el sistema o no se creo la lista filtrada.\n\n");
                }
                break;



            case 7:
                printf("\nDesea salir?(s/n): ");
                fflush(stdin);
                salir = getche();
                while(salir != 's' && salir != 'n')
                {
                    printf("\nError. Ingrese s o n: ");
                    fflush(stdin);
                    salir = getche();
                }
                printf("\n\n");
                break;
        }

        system("pause");

    }while(salir == 'n');

    return 0;
}
