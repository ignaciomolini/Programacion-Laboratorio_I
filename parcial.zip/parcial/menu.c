#include <stdlib.h>
#include <stdio.h>
#include "validaciones.h"

/** \brief Muestra y nos da a elegir una opcion del menu
 *
 * \return int Retorna la opcion elegida
 *
 */
int menu()
{
    char opcionChar[2];
    int opcion;

    system("cls");
    printf("***************************** Computadoras *****************************\n\n");
    printf("1- Cargar los datos de las computadoras desde el archivo datos_Fin.csv (modo texto)\n");
    printf("2- Ordenar segun IdTipo\n");
    printf("3- Imprimir los datos de las computadoras\n");
    printf("4- Asignar el campo oferta\n");
    printf("5- Filtrar laptop\n");
    printf("6- Generar archivo filtrado.csv\n");
    printf("7- Salir\n");
    printf("\nIngrese opcion: ");
    fflush(stdin);
    scanf("%s", opcionChar);
    while(!esNumerico(opcionChar) || atoi(opcionChar) < 0 || atoi(opcionChar) > 10)
    {
        printf("Error. Intente nuevamente: ");
        fflush(stdin);
        scanf("%s", opcionChar);
    }

    opcion = atoi(opcionChar);

    return opcion;
}
