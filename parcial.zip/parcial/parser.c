#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "computer.h"

/** \brief Parsea los datos los datos de los autos desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListCompu LinkedList*
 * \return int Retorna la cantidad de autos que se cargaron
 *
 */
int parser_CompuFromText(FILE* pFile , LinkedList* pArrayListCompu)
{
    int contador = 0;
    int cantidad = 0;
    int i = 0;
    char buffer[4][128];
    eComputer* auxCompu = NULL;

    if(pFile == NULL || pArrayListCompu == NULL)
    {
        printf("El archivo no existe o no se pudo conseguir memoria.\n");
        exit(EXIT_FAILURE);
    }


    while(!feof(pFile))
    {

        cantidad = fscanf(pFile, "%[^,],%[^,],%[^,],%[^\n]\n", buffer[0], buffer[1], buffer[2], buffer[3]);
        if(cantidad < 4)
        {
            break;
        }
        else
        {
            auxCompu = computer_newParametros(atoi(buffer[0]), buffer[1], atof(buffer[2]), atoi(buffer[3]));

            if(auxCompu != NULL)
            {
                if(ll_add(pArrayListCompu, auxCompu) == 0)
                {
                    contador++;
                }
            }
        }

    }
    return contador;
}
