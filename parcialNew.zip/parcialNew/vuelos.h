#ifndef VUELOS_H_INCLUDED
#define VUELOS_H_INCLUDED

typedef struct
{
    int idPiloto;
    char nombre[51];

}ePiloto;

typedef struct
{
    int idVuelo;
    int idDestino;
    int idPiloto;
    int partida;
    int llegada;
    char estadoVuelo[15];

}eVuelo;


typedef struct
{
    int idDestino;
    char descripcion[51];
    float precio;

}eDestino;

#endif // VUELOS_H_INCLUDED


int hardcodearVuelos(eVuelo vec[], int tamV, int cantidad);
eVuelo nuevoVuelo(int idVuelo, int idDestino, int idPiloto, int partida, int llegada);
int altaVuelos(int idVuelo, eVuelo listaVuelos[], int tamV, ePiloto listaPilotos[], int tamP, eDestino listaDestinos[], int tamD);
int buscarLibre(eVuelo listaVuelos[], int tamV);
void inicializarVuelos(eVuelo vec[], int tamV);
void cargarDescPiloto(int id,  ePiloto listaPilotos[], int tamP, char descPiloto[]);
void cargarDescDestino(int id,  eDestino listaDestinos[], int tamD, char descDestino[]);
void mostrarVuelo(eVuelo vuelo, ePiloto listaPilotos[], int tamP, eDestino listaDestinos[], int tamD);
int mostrarVuelos(eVuelo listaVuelos[], int tamV, ePiloto listaPilotos[], int tamP, eDestino listaDestino[], int tamD);
int bajaVuelo(eVuelo listaVuelos[], int tamV, ePiloto listaPilotos[], int tamP, eDestino listaDestinos[], int tamD);
