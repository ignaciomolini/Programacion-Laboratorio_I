
int esNumerico(char str[]);
int esNumericoFlotante(char str[]);
int esSoloLetras(char str[]);
int esSoloLetrasYGuiones(char str[]);
int esAlfaNumerico(char str[]);
int esAlfaNumericoYGuiones(char str[]);
void primeraLetraMayus(char str[]);
//int obtenerFecha(eFecha* fecha, char mensaje[], char mensajeError[]);
int esFechaValida(int dia, int mes, int anio);
int obtenerTelefono(char telefono[], char mensaje[], char mensajeError[], int intentos);
int obtenerEntero(int* var, char mensaje[], char mensajeError[], int max, int min, int intentos);
int obtenerNombre(char vec[], char mensaje[], char mensajeError[], int intentos);
//int compararFechas(eFecha fecha1, eFecha fecha2);

