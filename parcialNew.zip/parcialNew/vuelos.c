#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "vuelos.h"
#include "validaciones.h"

void inicializarVuelos(eVuelo vec[], int tamV)
{
    for(int i = 0; i < tamV; i++)
    {
        strcpy(vec[i].estadoVuelo, "vacio");
    }
}

int buscarLibre(eVuelo listaVuelos[], int tamV)
{
    int indice = -1;

    for(int i=0; i < tamV; i++)
    {
        if(strcmp(listaVuelos[i].estadoVuelo, "vacio") == 0)
        {
            indice = i;
            break;
        }
    }
    return indice;
}


void cargarDescPiloto(int id,  ePiloto listaPilotos[], int tamP, char descPiloto[])
{
    for(int i=0; i < tamP; i++)
    {
        if(id == listaPilotos[i].idPiloto)
        {
            strcpy(descPiloto, listaPilotos[i].nombre);
            break;
        }
    }
}

void cargarDescDestino(int id,  eDestino listaDestinos[], int tamD, char descDestino[])
{
    for(int i=0; i < tamD; i++)
    {
        if(id == listaDestinos[i].idDestino)
        {
            strcpy(descDestino, listaDestinos[i].descripcion);
            break;
        }
    }
}



void mostrarVuelo(eVuelo vuelo, ePiloto listaPilotos[], int tamP, eDestino listaDestinos[], int tamD)
{
    char descPiloto[51];
    char descDestino[51];
    cargarDescPiloto(vuelo.idPiloto, listaPilotos, tamP, descPiloto);
    cargarDescDestino(vuelo.idDestino, listaDestinos, tamD, descDestino);
    printf("|  %d  |   %10s  |    %20s  |   %2d  |  %2d |  %10s  |\n", vuelo.idVuelo, descDestino, descPiloto, vuelo.partida, vuelo.llegada, vuelo.estadoVuelo);
}



int mostrarVuelos(eVuelo listaVuelos[], int tamV, ePiloto listaPilotos[], int tamP, eDestino listaDestino[], int tamD)
{
    int flag = 0;

    printf("----------------------------------------------------------------------------------------\n");
    printf("| IdVuelo |     Destino    |    Piloto    |    Partida   |   Llegada  |    Estado   |\n");
    printf("-----------------------------------------------------------------------------------------\n");

    for(int i=0; i < tamV; i++)
    {
        if(strcmp(listaVuelos[i].estadoVuelo, "vacio") != 0)
        {
            mostrarVuelo(listaVuelos[i], listaPilotos, tamP, listaDestino, tamD);
            flag = 1;
        }
    }

    if( flag == 0)
    {
        system("cls");
        printf("\nNo hay vuelos que mostrar\n");
    }

    printf("\n");

    return flag;
}


int altaVuelos(int idVuelo, eVuelo listaVuelos[], int tamV, ePiloto listaPilotos[], int tamP, eDestino listaDestinos[], int tamD)
{
    int todoOk = 0;
    int idDestino;
    int idPiloto;
    int partida;
    int llegada;
    int indice;

    system("cls");
    printf("*****Alta vuelo*****\n\n");

    indice = buscarLibre(listaVuelos, tamV);

    if(indice == -1)
    {
        printf("Sistema completo!\n\n");
    }
    else
    {
        obtenerEntero(&idDestino, "Ingrese el id del destino: ", "Error. Ingrese el id del destino: ", 5003, 5000, 10);

        obtenerEntero(&idPiloto, "Ingrese el id del piloto: ", "Error. Ingrese el id del piloto: ", 202, 200, 10);

        obtenerEntero(&partida, "Ingrese el horario de partida: ", "Error. Ingrese el horario de partida: ", 24, 1, 10);

        obtenerEntero(&llegada, "Ingrese el horario de llegada: ", "Error. Ingrese el horario de llegada: ", 24, 1, 10);

        listaVuelos[indice] = nuevoVuelo(idVuelo, idDestino, idPiloto, partida, llegada);
        todoOk = 1;
        system("cls");
        printf("Alta existosa!!\n\n");

    }

    return todoOk;
}



eVuelo nuevoVuelo(int idVuelo, int idDestino, int idPiloto, int partida, int llegada)
{
    eVuelo vuelo;

    vuelo.idVuelo =  idVuelo;
    vuelo.idDestino = idDestino;
    vuelo.idPiloto = idPiloto;
    vuelo.partida = partida;
    vuelo.llegada = llegada;
    strcpy(vuelo.estadoVuelo, "activo");

    return vuelo;
}

int buscarVuelo(int idVuelo, eVuelo listaVuelos[], int tamV)
{
    int indice = -1;

    for(int i=0; i < tamV; i++)
    {
        if( listaVuelos[i].idVuelo == idVuelo && (strcmp(listaVuelos[i].estadoVuelo, "vacio") != 0))
        {
            indice = i;
            break;
        }
    }
    return indice;
}

int bajaVuelo(eVuelo listaVuelos[], int tamV, ePiloto listaPilotos[], int tamP, eDestino listaDestinos[], int tamD)
{
    int todoOk = 0;
    int id;
    int indice;
    char confirma;

    system("cls");
    printf("***** Baja vuelo *****\n\n");
    if(!mostrarVuelos(listaVuelos, tamV, listaPilotos, tamP, listaDestinos, tamD))
    {
        system("cls");
        printf("***** Baja vuelo *****\n\n");
        printf("No hay vuelos por dar de baja\n\n");
        return todoOk = 1;
    }
    printf("Ingrese codigo de vuelo: ");
    scanf("%d", &id);
    printf("\n");

    indice = buscarVuelo(id, listaVuelos, tamV);

    if( indice == -1)
    {
        printf("No existe un vuelo con ese codigo\n\n");
    }
    else
    {
        system("cls");
        printf("----------------------------------------------------------------------------------------\n");
        printf("| IdVuelo |     Destino    |    Piloto    |    Partida   |   Llegada  |    Estado   |\n");
        printf("-----------------------------------------------------------------------------------------\n");
        mostrarVuelo(listaVuelos[indice], listaPilotos, tamP, listaDestinos, tamD);

        printf("\nConfirma baja? ");
        fflush(stdin);
        scanf("%c", &confirma);

        if( confirma == 's')
        {
            strcpy(listaVuelos[indice].estadoVuelo, "vacio");
            todoOk = 1;
            printf("\nBaja exitosa!!!\n\n");
        }
        else
        {
            system("cls");
            printf("\nSe ha cancelado la operacion!\n\n");
        }
    }

    return todoOk;
}


int modificarEstadoVuelo(eVuelo listaVuelos[], int tamV, ePiloto listaPilotos[], int tamP, eDestino listaDestinos[], int tamD)
{
    int todoOk = 0;
    int id;
    int indice;
    int opcion;
    char estado[21];
    char salir = 'n';

    system("cls");
    printf("***** Modificar estado vuelo *****\n\n");
    if(!mostrarVuelos(listaVuelos, tamV, listaPilotos, tamP, listaDestinos, tamD))
    {
        system("cls");
        printf("***** Modificar vuelo *****\n\n");
        printf("No hay vuelos por modificar\n");
        return todoOk = 1;
    }
    printf("Ingrese codigo de vuelo: ");
    scanf("%d", &id);
    printf("\n");

    indice = buscarVuelo(id, listaVuelos, tamV);

    if( indice == -1)
    {
        printf("No existe un vuelo con ese codigo\n\n");
    }
    else
    {
        do
        {
            system("cls");
            printf("----------------------------------------------------------------------------------------\n");
            printf("| IdVuelo |     Destino    |    Piloto    |    Partida   |   Llegada  |    Estado   |\n");
            printf("-----------------------------------------------------------------------------------------\n");
            mostrarVuelo(listaVuelos[indice], listaPilotos, tamP, listaDestinos, tamD);

            printf("\n1- Modificar estado\n");
            printf("2- salir\n");
            obtenerEntero(&opcion, "Ingrese opcion: ", "Error. Ingrese opcion: ", 2, 1, 10);

            switch(opcion)
            {
                 case 1:
                    printf("Ingrese nuevo estado: ");
                    fflush(stdin);
                    gets(estado);
                    while(strlen(estado) < 5)
                    {
                        printf("Ingrese nuevo estado: ");
                        fflush(stdin);
                        gets(estado);
                    }
                    strcpy(listaVuelos[indice].estadoVuelo, estado);

                    break;


                 case 2:
                    printf("\nDesea salir?(s/n): ");
                    fflush(stdin);
                    salir = getche();
                    printf("\n\n");

                    while(salir != 's' && salir != 'n')
                    {
                        printf("Error. Ingrese s o n: ");
                        fflush(stdin);
                        salir = getche();
                        printf("\n\n");
                    }
                    break;
            }

        }while(salir == 'n');
    }

    return todoOk;
}
/*
int validar()
{
    strcmp(estado, "activo") != 0 || strcmp(estado, "demorado") != 0
                          || strcmp(estado, "suspendido") != 0 || strcmp(estado, "cancelado") != 0
}
*/

int hardcodearVuelos(eVuelo vec[], int tamV, int cantidad)
{
    int contador = 0;

    eVuelo suplentes[]=
    {
        { 1000, 5000, 201, 3, 10, "activo"},
        { 1001, 5003,202, 14, 20, "activo"},
        { 1002, 5001, 200, 13, 22, "activo"},
        { 1003, 5000, 202, 8, 14, "activo"},
        { 1004, 5002, 201, 9, 16, "activo"},
        { 1005, 5003, 202, 5, 19, "activo"},
        { 1006, 5001, 201, 16, 20, "activo"},
        { 1007, 5003, 200, 14, 21, "activo"},
        { 1008, 5002, 202, 15, 22, "activo"},
        { 1009, 5001, 201, 12, 17, "activo"},
    };

    if( cantidad <= 10 && tamV >= cantidad)
    {
        for(int i=0; i < cantidad; i++)
        {
            vec[i] = suplentes[i];
            contador++;
        }
    }

    return contador;
}
