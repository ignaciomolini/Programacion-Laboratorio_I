#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "vuelos.h"
#include "validaciones.h"

#define TAMV 20
#define TAMP 3
#define TAMD 4


int menu();

int main()
{
    char salir = 'n';
    int idVuelo = 1000;
    eVuelo listaVuelos[TAMV];
    ePiloto listaPilotos[TAMP] = {{200, "Gerardo Martinez"}, {201, "Hugo Alvarez"}, {202, "Rodolfo Montaner"}};
    eDestino listaDestinos[TAMD] = {{5000, "Cancun", 1000}, {5001, "Miami", 1200}, {5002, "Rio", 600}, {5003, "Dominicana", 900}};

    inicializarVuelos(listaVuelos, TAMV);
    idVuelo = idVuelo + hardcodearVuelos(listaVuelos, TAMV, 10);

    do
    {
        switch( menu())
        {
            case 1:
                if(altaVuelos(idVuelo, listaVuelos, TAMV, listaPilotos, TAMP, listaDestinos, TAMD))
                {
                    idVuelo++;
                }
                break;

            case 2:
                bajaVuelo(listaVuelos, TAMV, listaPilotos, TAMP, listaDestinos, TAMD);
                break;

            case 3:
                modificarEstadoVuelo(listaVuelos, TAMV, listaPilotos, TAMP, listaDestinos, TAMD);
                break;

            case 4:
                mostrarVuelos(listaVuelos, TAMV, listaPilotos, TAMP, listaDestinos, TAMD);
                break;

            case 5:

                break;

            case 6:
                printf("\nConfirma salir?: ");
                fflush(stdin);
                salir = getche();
                while(salir != 's' && salir != 'n')
                {
                    printf("\nError. Ingrese s/n: ");
                    fflush(stdin);
                    salir = getche();
                }
                printf("\n\n");
                break;

            default:
                printf("\nOpcion Invalida!\n\n");
        }
        system("pause");
    }
    while(salir == 'n');

    return 0;
}

int menu()
{
    int opcion;

    system("cls");
    printf("****** ABM *******\n\n");
    printf("1-Alta vuelo\n");
    printf("2-Baja vuelo\n");
    printf("3-Modificar vuelo\n");
    printf("4-Listar vuelos\n");
    printf("5-Informes\n");
    printf("6-Salir\n\n");

    obtenerEntero(&opcion, "Ingrese una opcion: ", "Error. Ingrese una opcion: ", 6, 1, 3);

    return opcion;
}



