#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    int legajo;
    char nombre[20];
    char apellido[30];
    float sueldo;

}eEmpleado;

eEmpleado* new_empleado();

int main()
{
    eEmpleado* lista[50];
    eEmpleado* emple;
    int i = 0;
    FILE* miArchivo;
    char legajo[10];
    char nombre[20];
    char apellido[20];
    char sueldo[20];

    miArchivo = fopen("datos.csv", "r");

    fscanf(miArchivo, "%[^,],%[^,],%[^,],%[^\n]\n", legajo, nombre, apellido, sueldo);

    while(!feof(miArchivo))
    {
        fscanf(miArchivo, "%[^,],%[^,],%[^,],%[^\n]\n", legajo, nombre, apellido, sueldo); // %[^,], lee hasta la coma y la excluye

        emple = new_empleado();

        emple->legajo = atoi(legajo);
        strcpy(emple->nombre, nombre);
        strcpy(emple->apellido, nombre);
        emple->sueldo = atof(sueldo);

        *(lista+i) = emple;

        i++;

        //printf("%d---%s---%s---%.2f\n", emple.legajo, emple.nombre, emple.apellido, emple.sueldo);
    }

    fclose(miArchivo);

    for(i=0; i < 50; i++)
    {
        printf("%d---%s---%s---%.2f\n", lista[i]->legajo, lista[i]->nombre, lista[i]->apellido, lista[i]->sueldo);
    }

    return 0;
}

eEmpleado* new_empleado()
{
    eEmpleado* e;

    e = (eEmpleado*) malloc(sizeof(eEmpleado));

    return e;
}
