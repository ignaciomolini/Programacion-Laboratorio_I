#include <stdio.h>
#include <stdlib.h>

#define TAM 5

void mostrarAlumnos(int[], int[], char[], int[], int[], float[], int tam);
void mostrarAlumno(int legajo, int edad, char sexo, int nota1, int nota2, float promedio);
void ordAlumnosLeg(int leg[], int age[], char sex[], int n1[], int n2[], float prom[], int tam);
void ordAlumnosSexLeg(int leg[], int age[], char sex[], int n1[], int n2[], float prom[], int tam);

int main()
{
    int legajos[TAM] = { 1234, 8322, 4556, 2122, 5532};
    int edades[TAM] = {22, 34, 21, 45, 20};
    char sexos[TAM] = {'f', 'f', 'm', 'f', 'm'};
    int notasP1[TAM] = { 2, 5, 6, 9, 10};
    int notasP2[TAM] = { 4, 4, 2, 10, 8};
    float promedios[TAM] = {3, 4.5, 4, 9.5, 9};

   /* for( int i=0; i < TAM; i++){
        printf("Ingrese legajo: ");
        scanf("%d", &legajos[i]);

        printf("Ingrese edad: ");
        scanf("%d", &edades[i]);

        printf("Ingrese sexo: ");
        fflush(stdin);
        scanf("%c", &sexos[i]);

        printf("Ingrese Nota parcial 1: ");
        scanf("%d", &notasP1[i]);

        printf("Ingrese Nota parcial 2: ");
        scanf("%d", &notasP2[i]);

        promedios[i] = (float)  (notasP1[i] + notasP2[i]) / 2;
    }*/

    mostrarAlumnos(legajos, edades, sexos, notasP1, notasP2, promedios, TAM );

    ordAlumnosSexLeg(legajos, edades, sexos, notasP1, notasP2, promedios, TAM );

    mostrarAlumnos(legajos, edades, sexos, notasP1, notasP2, promedios, TAM );

    return 0;
}


void mostrarAlumnos(int legs[], int ages[], char sexs[], int n1[], int n2[], float proms[], int tam){

    printf("Legajo  Edad Sexo Nota1 Nota2 Promedio\n\n");
    for(int i=0; i < tam; i++){
        mostrarAlumno( legs[i], ages[i], sexs[i], n1[i], n2[i], proms[i]);
    }
    printf("\n\n");
}

void mostrarAlumno(int legajo, int edad, char sexo, int nota1, int nota2, float promedio){

    printf("  %d     %d   %c   %d    %d     %.2f\n",
            legajo, edad, sexo, nota1, nota2, promedio);
}

void ordAlumnosLeg(int leg[], int age[], char sex[], int n1[], int n2[], float prom[], int tam)
{
    int auxInt;
    char auxChar;
    float auxFloat;

    for( int i = 0; i < tam-1; i++)
    {
        for( int j = i+1; j < tam; j++)
        {
           if( leg[i] > leg[j] )
            {
                auxInt = leg[i];
                leg[i] = leg[j];
                leg[j] = auxInt;

                auxInt = age[i];
                age[i] = age[j];
                age[j] = auxInt;

                auxChar = sex[i];
                sex[i] = sex[j];
                sex[j] = auxChar;

                auxInt = n1[i];
                n1[i] = n1[j];
                n1[j] = auxInt;

                auxInt = n2[i];
                n2[i] = n2[j];
                n2[j] = auxInt;

                auxFloat = prom[i];
                prom[i] = prom[j];
                prom[j] = auxFloat;


            }
        }
    }
}

void ordAlumnosSexLeg(int leg[], int age[], char sex[], int n1[], int n2[], float prom[], int tam)
{
    int auxInt;
    char auxChar;                // ordena primero por sexo y luego por legajo
    float auxFloat;
    int swap = 0;

    for( int i = 0; i < tam-1; i++)
    {
        for( int j = i+1; j < tam; j++)
        {
            if( sex[i] > sex[j] )
            {
                swap = 1;
            }
            else if( sex[i] == sex[j] && leg[i] > leg[j])
            {
                swap = 1;
            }

            if( swap )
            {
                auxInt = leg[i];
                leg[i] = leg[j];
                leg[j] = auxInt;

                auxInt = age[i];
                age[i] = age[j];
                age[j] = auxInt;

                auxChar = sex[i];
                sex[i] = sex[j];
                sex[j] = auxChar;

                auxInt = n1[i];
                n1[i] = n1[j];
                n1[j] = auxInt;

                auxInt = n2[i];
                n2[i] = n2[j];
                n2[j] = auxInt;

                auxFloat = prom[i];
                prom[i] = prom[j];
                prom[j] = auxFloat;
            }

            swap = 0;
        }
    }
}

